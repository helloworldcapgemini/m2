﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StreamReaderWriterDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fsWrite = new FileStream("Stream.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fsWrite);
            sw.WriteLine(12345);
            sw.WriteLine(23.456);
            sw.WriteLine(".NET Batch");
            sw.WriteLine(true);
            sw.WriteLine('C');
            sw.Flush();
            fsWrite.Close();
            Console.WriteLine("Data is written to file");

            FileStream fsRead = new FileStream("Stream.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fsRead);
            Console.WriteLine(sr.ReadToEnd());

            Console.ReadKey();
        }
    }
}
