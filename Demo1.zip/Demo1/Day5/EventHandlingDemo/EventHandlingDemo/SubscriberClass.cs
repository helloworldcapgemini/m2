﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlingDemo
{
    public class SubscriberClass
    {
        public static void OnClick(string message)
        {
            Console.WriteLine(message);
        }
    }
}
