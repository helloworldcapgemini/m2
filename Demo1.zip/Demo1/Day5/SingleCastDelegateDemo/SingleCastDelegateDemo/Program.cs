﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleCastDelegateDemo
{
    public delegate double MathDelegate(double num);

    class Program
    {
        public double CircleArea(double radius)
        {
            return 3.14 * radius * radius;
        }

        static void Main(string[] args)
        {
            MathDelegate del = new MathDelegate(Math.Sin);
            double val = del(1.0);
            Console.WriteLine("Sin(1.0) : " + val);

            Program p = new Program();
            del = new MathDelegate(p.CircleArea);
            double area = del.Invoke(3);
            Console.WriteLine("Area of Circle is : " + area);
            Console.ReadKey();
        }
    }
}
