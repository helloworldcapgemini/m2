﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    public class StudentValidation
    {
        public static bool ValidateStudent(Student stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try 
            {
                if (stud.StudentID < 100000 || stud.StudentID > 999999)
                {
                    message.Append("Student ID should be 6 digits\n");
                    studValidated = false;
                }

                if (stud.StudentName == String.Empty)
                {
                    message.Append("Student Name should be provided\n");
                    studValidated = false;
                }
                else if (!Regex.IsMatch(stud.StudentName, "[A-Z][a-z]+"))
                {
                    message.Append("Student name should start with capital alphabet and it should have alphabets only\n");
                    studValidated = false;
                }

                if ((DateTime.Today.Year - stud.DOB.Year) < 16)
                {
                    message.Append("Student Age should be greater than 16\n");
                    studValidated = false;
                }

                if (stud.Phone == string.Empty)
                {
                    message.Append("Phone Number should be provided\n");
                    studValidated = false;
                }
                else if (!Regex.IsMatch(stud.Phone, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    studValidated = false;
                }

                if (stud.Course == string.Empty)
                {
                    message.Append("Course Name should be provided\n");
                    studValidated = false;
                }
                else if (stud.Course.ToLower() != ".net"
                    || stud.Course.ToLower() != "java"
                    || stud.Course.ToLower() != "system"
                    || stud.Course.ToLower() != "bi")
                {
                    message.Append("Course should be either .NET or JAVA or System OR BI\n");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static bool AddStudent(Student stud)
        {
            bool studAdded = false;

            try 
            {
                if (ValidateStudent(stud))
                {
                    studAdded = StudentOperations.AddStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid data for student");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studAdded;
        }

        public static bool ModifyStudent(Student stud)
        {
            bool studModified = false;

            try
            {
                if (ValidateStudent(stud))
                {
                    studModified = StudentOperations.ModifyStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid data for Student");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studModified;
        }

        public static bool DeleteStudent(int studID)
        {
            bool studDeleted = false;

            try 
            {
                studDeleted = StudentOperations.DeleteStudent(studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studDeleted;
        }

        public static Student SearchStudent(int studID)
        {
            Student stud = null;

            try 
            {
                stud = StudentOperations.SearchStudent(studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = StudentOperations.RetrieveStudent();

            return studList;
        }

        public static bool SerializeStudent()
        {
            bool studSerialized = false;

            try 
            {
                studSerialized = StudentOperations.SerializeStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studSerialized;
        }

        public static List<Student> DeserializeStudent()
        {
            List<Student> desStudList = null;

            try 
            {
                desStudList = StudentOperations.DeserializeStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desStudList;
        }
    }
}
