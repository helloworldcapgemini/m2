﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo2
{
    public class Manager : Employee
    {
        public Manager() : base()
        {
            Console.WriteLine("Manager class default constructor");
        }

        public Manager(int id, string name, double incentives) : base(id, name)
        {
            Console.WriteLine("Manager class parameterized constructor");
        }
    }
}
