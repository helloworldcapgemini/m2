﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritanceDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager mgr = new Manager();

            Console.WriteLine();

            Manager mgr1 = new Manager(101, "Robert", 15000);
            
            Console.ReadKey();
        }
    }
}
