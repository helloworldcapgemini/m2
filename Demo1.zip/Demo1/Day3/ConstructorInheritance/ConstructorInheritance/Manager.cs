﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritance
{
    public class Manager : Employee
    {
        public Manager()
        {
            Console.WriteLine("Manager class default constructor");
        }

        public Manager(int id, string name, double incentives)
        {
            Console.WriteLine("Manager class parameterized constructor");
        }
    }
}
