﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersDemo
{
    public class Locations
    {
        string[] cities;

        public Locations(int size)
        {
            cities = new string[size];
        }


        public string this[int i]
        {
            get { return cities[i]; }
            set { cities[i] = value; }
        }
    }
}
