﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementaionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee();
            //emp.Show();
            //emp.Display();
            //emp.Print();
            //Console.WriteLine();

            IShow empShow = new Employee();
            empShow.Show();
            empShow.Display();

            Console.WriteLine();
            
            IPrint empPrint = new Employee();
            empPrint.Show();
            empPrint.Print();

            Console.ReadKey();
        }
    }
}
