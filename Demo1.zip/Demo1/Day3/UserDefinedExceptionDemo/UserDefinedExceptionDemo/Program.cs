﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedExceptionDemo
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee emp = new Employee();
                Console.Write("Enter Employee ID : ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());

                if (emp.EmployeeID < 100000 || emp.EmployeeID > 999999)
                {
                    throw new EmployeeException("Employee ID should be 6 digits");
                }

                Console.Write("Enter Employee Name : ");
                emp.EmployeeName = Console.ReadLine();
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
