﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParametersDemo
{
    class Program
    {
        public static void SwapByVal(int num1, int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public static void SwapByRef(ref int num1, ref int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public static void CircleCalc(double radius, out double area, out double circum)
        {
            area = 3.14 * radius * radius;
            circum = 2 * 3.14 * radius;
        }

        public static int Addition(params int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum = sum + arr[i];
            }

            return sum;
        }

        static void Main(string[] args)
        {
            int num1 = 40, num2 = 65;

            Console.WriteLine("********************Pass By Value*******************");
            Console.WriteLine("Before Swapping : ");
            Console.WriteLine("\tNum 1 : " + num1);
            Console.WriteLine("\tNum 2 : " + num2);

            SwapByVal(num1, num2);

            Console.WriteLine("After Swapping : ");
            Console.WriteLine("\tNum 1 : " + num1);
            Console.WriteLine("\tNum 2 : " + num2);

            Console.WriteLine("********************Pass By Reference*******************");
            Console.WriteLine("Before Swapping : ");
            Console.WriteLine("\tNum 1 : " + num1);
            Console.WriteLine("\tNum 2 : " + num2);

            SwapByRef(ref num1, ref num2);

            Console.WriteLine("After Swapping : ");
            Console.WriteLine("\tNum 1 : " + num1);
            Console.WriteLine("\tNum 2 : " + num2);

            Console.WriteLine("********************Pass By Out*******************");
            double radius = 4.5;
            double area, circum;

            CircleCalc(radius, out area, out circum);

            Console.WriteLine("Area of Circle is : " + area);
            Console.WriteLine("Cricumference of Circle is : " + circum);

            Console.WriteLine("********************Parameterized Array*******************");
            Console.WriteLine("With 2 parameters : " + Addition(23, 12));
            Console.WriteLine("With 0 parameters : " + Addition());
            Console.WriteLine("With 5 parameters : " + Addition(12, 34, 23, 65, 76));
            Console.WriteLine("With 4 parameters : " + Addition(90, 80, 70, 60));

            Console.ReadKey();
        }
    }
}
