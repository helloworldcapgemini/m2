﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedProperty
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            Console.Write("Enter Employee ID : ");
            emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Employee Name : ");
            emp.EmployeeName = Console.ReadLine();
            Console.Write("Enter Salary : ");
            emp.Salary = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter City : ");
            emp.City = Console.ReadLine();

            Console.WriteLine("\n\n\nEmployee ID : " + emp.EmployeeID);
            Console.WriteLine("Employee Name : " + emp.EmployeeName);
            Console.WriteLine("Salary : " + emp.Salary);
            Console.WriteLine("City : " + emp.City);

            Console.ReadKey();
        }
    }
}
