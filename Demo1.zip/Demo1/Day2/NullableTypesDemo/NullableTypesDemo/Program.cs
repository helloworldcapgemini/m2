﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableTypesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int? num = 100;

            if (num.HasValue)
            {
                Console.WriteLine("Number Value : " + num.Value);
            }
            else
            {
                Console.WriteLine("Number Value : null");
            }
        }
    }
}
