﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrList = new ArrayList();

            arrList.Add(12345);
            arrList.Add(3.14);
            arrList.Add(true);
            arrList.Add("Capgemini");
            arrList.Add(".NET");
            arrList.Add(151);
            arrList.Add('C');
            arrList.Add(false);
            arrList.Add(9876543);
            Console.WriteLine("Capacity : " + arrList.Capacity);
            Console.WriteLine("Number of Elements (Count) : " + arrList.Count);

            Console.WriteLine("ArrayList Element using For Loop : ");
            for (int i = 0; i < arrList.Count; i++)
            {
                Console.Write(arrList[i] + "\t");
            }

            Console.WriteLine();
            Console.WriteLine("ArrayList Element using ForEach Loop : ");
            foreach (object item in arrList)
            {
                Console.Write(item + "\t");
            }

            Console.WriteLine();
            object[] arr = new object[15];
            
            //CopyTo(array) - Copies entire collection into array and paste it in array from index 0
            //arrList.CopyTo(arr);
            
            //CopyTo(array, arrayIndex) - Copies entire collection into array and paste it in array from index provided in arrayIndex
            //arrList.CopyTo(arr, 3);

            //CopyTo(collectionIndex, array, arrayIndex, NumberofElementsFromCollection)
            //Copies the elements from collectionIndex till the number of elements from collection and paste it in array from index provided in arrayIndex
            arrList.CopyTo(3, arr, 6, 5);

            Console.WriteLine("\n\nElements from Array : ");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == null)
                    Console.Write("null" + "\t");
                else
                    Console.Write(arr[i] + "\t");
            }            
            
            Console.ReadKey();
        }
    }
}
