﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            object o = ".NET Batch";

            string s = ".NET Batch";
            s.ToUpper();

            var v = ".NET Batch";
            v.ToUpper();

            dynamic d = ".NET Batch";
            Console.WriteLine(d.ToUpper());
            Console.ReadKey();
        }
    }
}
