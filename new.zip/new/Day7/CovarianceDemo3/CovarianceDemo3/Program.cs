﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovarianceDemo3
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            EmpID = id;
            Name = name;
        }
    }

    public class Manager : Employee
    {
        public int Allowance { get; set; }

        public Manager(int id, string name, int allw)
            : base(id, name)
        {
            Allowance = allw;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IList<Manager> mgrList = new List<Manager>();

            mgrList.Add(new Manager(101, "Robert", 2000));
            mgrList.Add(new Manager(102, "John", 2200));
            mgrList.Add(new Manager(103, "Vel", 3000));
            mgrList.Add(new Manager(104, "Jasmin", 2500));
            mgrList.Add(new Manager(105, "Allister", 5000));

            IEnumerable<Employee> empList = mgrList;

            Console.WriteLine("Manager Info");
            foreach (var e in empList)
            {
                Console.WriteLine(e.EmpID + "\t" + e.Name);
            }

            Console.ReadKey();
        }
    }
}
