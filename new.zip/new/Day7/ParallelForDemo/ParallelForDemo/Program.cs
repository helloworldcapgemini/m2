﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;

namespace ParallelForDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = new Stopwatch();
            int serialTime;
            int parallelTime;

            sw = Stopwatch.StartNew();
            RunInSerial();
            sw.Stop();
            serialTime = sw.Elapsed.Milliseconds;

            sw = Stopwatch.StartNew();
            RunInParallel();
            sw.Stop();
            parallelTime = sw.Elapsed.Milliseconds;

            Console.WriteLine("Time taken by sequential method : " + serialTime);
            Console.WriteLine("Time taken by parallel method : " + parallelTime);

            Console.ReadKey();
        }

        public static void RunInSerial()
        {
            for (int i = 0; i < 25; i++)
            {
                Console.WriteLine("Serial Index : " + i);
                Thread.Sleep(30);
            }
        }

        public static void RunInParallel()
        {
            Parallel.For(0, 25, 
                i => { 
                    Console.WriteLine("Parallel Index : " + i); 
                    Thread.Sleep(30); 
                });
        }
    }
}
