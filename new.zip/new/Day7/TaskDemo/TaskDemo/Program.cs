﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace TaskDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = new Stopwatch();
            sw = Stopwatch.StartNew();
            BookPlane();
            BookCar();
            BookHotel();
            Console.WriteLine("Total Time Elapsed in Sequential Process : " + sw.ElapsedMilliseconds);
            Console.WriteLine();

            sw=Stopwatch.StartNew();
            Task plane = Task.Factory.StartNew(()=>BookPlane());
            Task car = Task.Factory.StartNew(() => BookCar());
            Task hotel = Task.Factory.StartNew(() => BookHotel());

            Task.WaitAll(plane, car, hotel);
            Console.WriteLine("Total Time Elapsed in Parallel Process : " + sw.ElapsedMilliseconds);
        }

        public static void BookCar()
        {
            Console.WriteLine("Car Booking Started...");
            Thread.Sleep(3000);
            Console.WriteLine("Car Booking Done!!!");
        }

        public static void BookPlane()
        {
            Console.WriteLine("Plane Booking Started...");
            Thread.Sleep(5000);
            Console.WriteLine("Plane Booking Done!!!");
        }

        public static void BookHotel()
        {
            Console.WriteLine("Hotel Booking Started...");
            Thread.Sleep(8000);
            Console.WriteLine("Hotel Booking Done!!!");
        }
    }
}
