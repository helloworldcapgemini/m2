﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public class Employee
    {
        int empID;

        public int EmployeeID
        {
            get { return empID; }
            set { empID = value; }
        }

        string name;
        public string EmployeeName
        {
            get { return name; }
            set { name = value; }
        }

        double sal;
        public double Salary
        {
            get { return sal; }
            set { sal = value; }
        }

        public Employee()
        {
            empID = 0;
            name = null;
            sal = 0.0;
        }

        public Employee(int id, string name, double sal)
        {
            this.empID = id;
            this.name = name;
            this.sal = sal;
        }
    }
}
