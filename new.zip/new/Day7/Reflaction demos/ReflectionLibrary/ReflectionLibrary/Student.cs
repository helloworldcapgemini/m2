﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public struct Student
    {
        int no;
        string name;

        public int RollNo
        {
            get { return no; }
            set { no = value; }
        }

        public string StudentName
        {
            get { return name; }
            set { name = value; }
        }
    }
}
