﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly reflection = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type[] refTypes = reflection.GetTypes();

            for (int i = 0; i < refTypes.Length; i++)
            {
                Console.WriteLine("Type Name : " + refTypes[i].Name);
                Console.WriteLine("Assembly Qualified Name : " + refTypes[i].AssemblyQualifiedName);
                if (refTypes[i].BaseType != null)
                {
                    Console.WriteLine("Base Type : " + refTypes[i].BaseType.Name);
                }
                Console.WriteLine("Contains Generic Parameters : " + refTypes[i].ContainsGenericParameters);
                Console.WriteLine("Full Name : " + refTypes[i].FullName);
                Console.WriteLine("Is Abstract : " + refTypes[i].IsAbstract);
                Console.WriteLine("Is Ansi Class : " + refTypes[i].IsAnsiClass);
                Console.WriteLine("Is Array : " + refTypes[i].IsArray);
                Console.WriteLine("Is Auto Class : " + refTypes[i].IsAutoClass);
                Console.WriteLine("Is Class : " + refTypes[i].IsClass);
                Console.WriteLine("Is Enum : " + refTypes[i].IsEnum);
                Console.WriteLine("Is Generic Parameter : " + refTypes[i].IsGenericParameter);
                Console.WriteLine("Is Generic Type : " + refTypes[i].IsGenericType);
                Console.WriteLine("Is Interface : " + refTypes[i].IsInterface);
                Console.WriteLine("Is Primitive : " + refTypes[i].IsPrimitive);
                Console.WriteLine("Is Public : " + refTypes[i].IsPublic);
                Console.WriteLine("Is Sealed : " + refTypes[i].IsSealed);
                Console.WriteLine("Is Serializable : " + refTypes[i].IsSerializable);
                Console.WriteLine("Is Value Type : " + refTypes[i].IsValueType);
                Console.WriteLine("Namespace : " + refTypes[i].Namespace);
                Console.WriteLine("**************************************************************************************");
            }

            Console.ReadKey();
        }
    }
}
