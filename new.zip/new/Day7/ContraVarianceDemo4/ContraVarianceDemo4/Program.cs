﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContraVarianceDemo4
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string Name { get; set; }
        public int DeptID { get; set; }

        public Employee(int id, string name, int did)
        {
            EmpID = id;
            Name = name;
            DeptID = did;
        }
    }

    public class EmployeeComparer : IComparer<Employee>
    {
        public int Compare(Employee x, Employee y)
        {
            if (x.DeptID > y.DeptID)
            {
                return 1;
            }
            else if (x.DeptID < y.DeptID)
            {
                return -1;
            }

            return 0;
        }
    }

    public class Manager : Employee
    {
        public int Allowance { get; set; }

        public Manager(int id, string name, int did, int allw)
            : base(id, name, did)
        {
            Allowance = allw;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee(101, "Robert", 30));
            empList.Add(new Employee(102, "John", 50));
            empList.Add(new Employee(103, "Ann", 10));
            empList.Add(new Employee(104, "Vel", 20));
            empList.Add(new Employee(105, "Steve", 30));
            empList.Add(new Employee(106, "Ruby", 20));
            empList.Add(new Employee(107, "Jenny", 10));
            empList.Add(new Employee(108, "Jason", 30));
            empList.Add(new Employee(109, "Sofia", 40));

            EmployeeComparer empCompare = new EmployeeComparer();
            empList.Sort(empCompare);

            Console.WriteLine("Sorted Employees : ");
            foreach (Employee emp in empList)
            {
                Console.WriteLine(emp.EmpID + "\t" + emp.Name + "\t" + emp.DeptID);
            }

            List<Manager> mgrList = new List<Manager>();

            mgrList.Add(new Manager(301, "Allister", 20, 3000));
            mgrList.Add(new Manager(302, "Jenny", 10, 3000));
            mgrList.Add(new Manager(303, "Ana", 20, 3000));
            mgrList.Add(new Manager(304, "George", 50, 3000));
            mgrList.Add(new Manager(305, "Suzan", 40, 3000));
            mgrList.Add(new Manager(306, "Jasmin", 20, 3000));
            mgrList.Add(new Manager(307, "Walt", 30, 3000));
            mgrList.Add(new Manager(308, "Tennyson", 20, 3000));
            mgrList.Add(new Manager(309, "Steven", 30, 3000));

            mgrList.Sort(empCompare);
            Console.WriteLine("\nSorted List of Manager : ");
            mgrList.ForEach(m => { Console.WriteLine(m.EmpID + "\t" + m.Name + "\t" + m.DeptID + "\t" + m.Allowance); });

            Console.ReadKey();
        }
    }
}
