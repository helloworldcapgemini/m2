﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeDemo
{
    [Author("Shital Patil")]
    [Serializable]
    public class Product
    {
        int id;
        public int ProductID { get { return id; } }

        string name;
        public string ProductName { get { return name; } set { name = value; } }

        int price;
        public int Price { get { return price; } set { price = value; } }

        int qty;
        public int Quantity { get { return qty; } set { qty = value; } }

        int total;
        public int TotalPrice { get { return total; } }

        public Product(int id)
        {
            this.id = id;
        }

        public void CalculateTotal()
        {
            this.total = this.price * this.qty;
        }
    }
}
