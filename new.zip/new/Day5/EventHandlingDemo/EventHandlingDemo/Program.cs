﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            PublisherClass pubObj = new PublisherClass();

            pubObj.MyClickEvent += SubscriberClass.OnClick;

            pubObj.EventNotification("Click Event Occured");

            Console.ReadKey();
        }
    }
}
