﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlingDemo
{
    public delegate void EventDelegate(string message);

    public class PublisherClass
    {
        public event EventDelegate MyClickEvent;

        public void EventNotification(string message)
        {
            if (MyClickEvent != null)
                MyClickEvent(message);
        }
    }
}
