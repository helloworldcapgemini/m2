﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegateDemo
{
    public delegate void CalculateDelegate(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();
            CalculateDelegate del = new CalculateDelegate(cal.Add);
            del += new CalculateDelegate(cal.Divide);
            del += Calculate.Subtract;
            del += new CalculateDelegate(cal.Add);
            del += new CalculateDelegate(Calculate.Multiply);

            del(12, 4);

            del -= new CalculateDelegate(cal.Add);

            Console.WriteLine("\nAfter removing Add Method : ");
            del(24, 3);

            Delegate[] invocationList = del.GetInvocationList();

            foreach (var item in invocationList)
            {
                Console.WriteLine(item.Method);
            }

            Console.ReadKey();
        }
    }
}
