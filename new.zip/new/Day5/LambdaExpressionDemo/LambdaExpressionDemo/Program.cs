﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionDemo
{
    public delegate void LambdaWithoutParamDel();

    class Program
    {
        static void Main(string[] args)
        {
            LambdaWithoutParamDel an = delegate {
                Console.WriteLine("Anonymous Method called using Delegate");
            };

            an();

            LambdaWithoutParamDel ld = () => Console.WriteLine("Lambda Expression called using Delegate");

            ld();

            Console.ReadKey();
        }
    }
}
