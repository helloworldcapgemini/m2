﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BinaryReaderWriteDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fsWrite = new FileStream(@"..\..\binary.txt", FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fsWrite);
            bw.Write(12345);
            bw.Write(23.456);
            bw.Write(".NET Batch");
            bw.Write(true);
            bw.Write('C');
            fsWrite.Close();
            Console.WriteLine("Data is written to the file");

            FileStream fsRead = new FileStream(@"..\..\binary.txt", FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fsRead);
            Console.WriteLine(br.ReadInt32());
            Console.WriteLine(br.ReadDouble());
            Console.WriteLine(br.ReadString());
            Console.WriteLine(br.ReadBoolean());
            Console.WriteLine(br.ReadChar());
            fsRead.Close();

            Console.ReadKey();
        }
    }
}
