﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace IDeserializationCallBackDemo
{
    [Serializable]
    public class Product : IDeserializationCallback
    {
        int id;
        string name;
        int price;
        int qty;
        [NonSerialized]
        int total;

        public Product(int id, string name, int price, int qty)
        {
            this.id = id;
            this.name = name;
            this.price = price;
            this.qty = qty;
            this.total = this.price * this.qty;
        }

        public int ProductID 
        {
            get { return id; }
            set { id = value; }
        }

        public string ProductName 
        {
            get { return name; }
            set { name = value; }
        }

        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        public int Quantity 
        {
            get { return qty; }
            set { qty = value; }
        }

        public int TotalPrice 
        {
            get { return total; }
        }

        public void OnDeserialization(object sender)
        {
            total = price * qty;
        }
    }
}
