﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo2
{
    public class Calculate
    {
        public IEnumerable Power(int num, int exp)
        {
            int cnt = 1;
            int result = 1;
            while (cnt <= exp)
            {
                result = result * num;
                cnt++;
                yield return result;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            foreach (var ele in cal.Power(2,5))
            {
                Console.WriteLine(ele);
            }

            Console.ReadKey();
        }
    }
}
