﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstraintsDemo
{
    public class GenericClass<T> where T : class
    { }

    public struct Student
    {
        public int StudID { get; set; }
        public string StudName { get; set; }
    }


    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            GenericClass<int> intGen = new GenericClass<int>();
            GenericClass<bool> boolGen = new GenericClass<bool>();
            GenericClass<Student> studGen = new GenericClass<Student>();

            GenericClass<object> objGen = new GenericClass<object>();
            GenericClass<string> strGen = new GenericClass<string>();
            GenericClass<Employee> empGen = new GenericClass<Employee>();
            GenericClass<System.Collections.IEnumerable> enuGen = new GenericClass<System.Collections.IEnumerable>();
        }
    }
}
