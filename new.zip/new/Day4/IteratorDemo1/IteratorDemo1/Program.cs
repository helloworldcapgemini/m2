﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo1
{
    public class WeekDays : IEnumerable
    {
        string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };


        IEnumerator IEnumerable.GetEnumerator()
        {
            for (int i = 0; i < days.Length; i++)
            {
                yield return days[i];
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            WeekDays week = new WeekDays();

            foreach (var day in week)
            {
                Console.WriteLine(day);
            }

            Console.ReadKey();
        }
    }
}
