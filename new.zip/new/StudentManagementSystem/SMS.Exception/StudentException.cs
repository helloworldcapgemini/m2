﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Description : This class is for handling the Student Exception
    /// Date of Creation : 16-Oct-2017
    /// </summary>
    public class StudentException : ApplicationException
    {
        //Default Constructor
        public StudentException()
            : base()
        { }

        //Parameterized Constructor with message parameter
        public StudentException(string message)
            : base(message)
        { }
    }
}
