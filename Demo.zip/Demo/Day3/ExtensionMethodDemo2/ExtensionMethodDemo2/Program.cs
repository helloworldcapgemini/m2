﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo2
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string DepartmentName { get; set; }
    }

    public static class EmployeeExtension
    {
        public static string PrintEmployeeInfo(this Employee emp)
        {
            return "Employee " + emp.EmployeeName + " with Employee ID " + emp.EmployeeID + " is working in " + emp.DepartmentName + " department.";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmployeeID = 111111;
            emp.EmployeeName = "Gunjan";
            emp.DepartmentName = "Support";

            Console.WriteLine(emp.PrintEmployeeInfo());

            Console.ReadKey();
        }
    }
}
