﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            try
            {
                Console.Write("Enter Number 1 : ");
                num1 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Number 2 : ");
                num2 = Convert.ToInt32(Console.ReadLine());

                int result = num1 / num2;

                int[] arr = new int[5];

                arr[0] = 12;
                arr[1] = 15;
                arr[2] = 23;
                arr[3] = 54;
                arr[4] = 78;
                arr[5] = 90;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Finally Block Executed !!!");
            }

            Console.ReadKey();
        }
    }
}
