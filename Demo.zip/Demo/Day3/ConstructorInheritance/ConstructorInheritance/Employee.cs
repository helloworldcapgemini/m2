﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritance
{
    public class Employee
    {
        public Employee()
        {
            Console.WriteLine("Employee class default constructor");
        }

        public Employee(int id, string name)
        {
            Console.WriteLine("Employee class parameterized constructor");
        }
    }
}
