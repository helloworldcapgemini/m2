﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrrideDemo
{
    public class Employee
    {
        public virtual void Show()
        {
            Console.WriteLine("Employee class Show() method");
        }
    }
}
