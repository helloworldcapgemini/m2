﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrrideDemo
{
    public class Manager : Employee
    {
        public override void Show()
        {
            Console.WriteLine("Manager class Show() method");
        }
    }
}
