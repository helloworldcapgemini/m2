﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var person1 = new { Name = "Mary", Age = 30 };
            var person2 = new { Name = "John", Age = 43 };
            var person3 = new { Age = 30, Name = "Vidisha" };

            Console.WriteLine("Name : " + person1.Name);
            Console.WriteLine("Age : " + person1.Age);

            Console.WriteLine("\nName : " + person2.Name);
            Console.WriteLine("Age : " + person2.Age);

            Console.WriteLine("\nName : " + person3.Name);
            Console.WriteLine("Age : " + person3.Age);

            Console.ReadKey();
        }
    }
}
