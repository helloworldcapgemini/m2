﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Locations loc = new Locations(10);

            loc[0] = "Pune";
            loc[3] = "Banglore";
            loc[5] = "Hyderabad";
            loc[4] = "Chennai";
            loc[9] = "Noida";
            loc[6] = "Kolkatta";
            loc[8] = "Mumbai";

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(loc[i]);
            }

            Console.ReadKey();
        }
    }
}
