﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementaionDemo
{
    public class Employee : IShow, IPrint
    {
        void IShow.Show()
        {
            Console.WriteLine("Employee class Show() method from IShow Interface");
        }

        void IShow.Display()
        {
            Console.WriteLine("Employee class Display() method from IShow Interface");
        }

        void IPrint.Print()
        {
            Console.WriteLine("Employee class Print() method from IPrint Interface");
        }

        void IPrint.Show()
        {
            Console.WriteLine("Employee class Show() method from IPrint Interface");
        }
    }
}
