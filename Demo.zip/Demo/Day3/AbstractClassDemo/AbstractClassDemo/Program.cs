﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee(); //Error : cannot create instance of abstract class Employee

            Employee emp = new Manager();

            emp.CalculateSalary();
            emp.Show();


        }
    }
}
