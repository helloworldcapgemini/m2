﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializersDemo
{
    public class Customer
    {
        public int CustomerID { get; private set; }
        public string Name { get; set; }
        public string City { get; set; }

        public Customer(int id)
        {
            CustomerID = id;
        }
    }

    class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public double Salary { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer(101) { Name="Mary", City="Berlin" };
            //c.Name = "Mary";
            //c.City = "Berlin";

            Console.WriteLine("Customer ID : " + c.CustomerID);
            Console.WriteLine("Customer Name : " + c.Name);
            Console.WriteLine("Customer City : " + c.City);


            Employee emp = new Employee { EmployeeID = 123456, EmployeeName = "Vidisha", Salary = 30000 };
            Console.WriteLine("\n\n\nEmployee ID : " + emp.EmployeeID);
            Console.WriteLine("Employee Name : " + emp.EmployeeName);
            Console.WriteLine("Employee Salary : " + emp.Salary);
        }
    }
}
