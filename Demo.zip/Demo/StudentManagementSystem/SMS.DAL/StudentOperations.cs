﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;       //Reference for Student Entity
using SMS.Exception;    //Reference for Student Exception
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace SMS.DAL
{
    /// <summary>
    /// Employee ID : 
    /// Employee Name : 
    /// Description : 
    /// Date of Creation : 16-Oct-2017
    /// </summary>
    public class StudentOperations
    {
        static List<Student> studList = new List<Student>();

        //Function to add new student record in collection
        public static bool AddStudent(Student stud)
        {
            bool studAdded = false;

            try 
            {
                //Adding student record in collection
                studList.Add(stud);
                studAdded = true;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studAdded;
        }

        //Function to modify student record
        public static bool ModifyStudent(Student stud)
        {
            bool studModified = false;

            try 
            {
                for (int i = 0; i < studList.Count; i++)
                {
                    //Searching Student
                    if (studList[i].StudentID == stud.StudentID)
                    {
                        //Modifying Student Record
                        studList[i].StudentName = stud.StudentName;
                        studList[i].DOB = stud.DOB;
                        studList[i].Phone = stud.Phone;
                        studList[i].Course = stud.Course;
                        studModified = true;
                    }
                }
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studModified;
        }

        //Function to delete student record from collection
        public static bool DeleteStudent(int studID)
        {
            bool studDeleted = false;

            try 
            {
                //Searching the record
                Student studenttoDelete = studList.Find(s => s.StudentID == studID);

                if (studenttoDelete != null)
                {
                    //Removing the record
                    studList.Remove(studenttoDelete);
                    studDeleted = true;
                }
                else
                    throw new StudentException("Student Record not Available for Deletion with ID : " + studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studDeleted;
        }

        //Function to search student record based on Student ID
        public static Student SearchStudent(int studID)
        {
            Student stud = null;

            try 
            {
                //searching record from collection
                stud = studList.Find(s => s.StudentID == studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //Function to retrieve all students
        public static List<Student> RetrieveStudent()
        {
            return studList;
        }

        //Function to Serialialize Student Record
        public static bool SerializeStudent()
        {
            bool serialized = false;

            try
            {
                FileStream fs = new FileStream("Student.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, studList);
                fs.Close();
                serialized = true;
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return serialized;
        }

        public static List<Student> DeserializeStudent()
        {
            List<Student> desStudList = null;

            try 
            {
                FileStream fs = new FileStream("Student.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desStudList = (List<Student>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desStudList;
        }
    }
}
