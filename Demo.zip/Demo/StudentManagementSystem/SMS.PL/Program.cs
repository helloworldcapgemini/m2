﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.PL
{
    class Program
    {
        public static void AddStudent()
        {
            Student stud = new Student();

            try 
            {
                Console.Write("Enter Student ID : ");
                stud.StudentID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Student Name : ");
                stud.StudentName = Console.ReadLine();
                Console.Write("Enter Student Date of Birth : ");
                stud.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Student Phone Number : ");
                stud.Phone = Console.ReadLine();
                Console.Write("Enter Course : ");
                stud.Course = Console.ReadLine();

                bool studAdded = StudentValidation.AddStudent(stud);

                if (studAdded)
                    Console.WriteLine("Student Record Added Successfully");
                else
                    throw new StudentException("Student Record Not Added");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void ModifyStudent()
        {
            Student stud = new Student();

            try 
            {
                Console.Write("Enter Student ID for which you would like to modify data : ");
                stud.StudentID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Modified Student Name : ");
                stud.StudentName = Console.ReadLine();
                Console.Write("Enter Modified Student Date of Birth : ");
                stud.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Modified Student Phone Number : ");
                stud.Phone = Console.ReadLine();
                Console.Write("Enter Modified Course : ");
                stud.Course = Console.ReadLine();

                bool studModified = StudentValidation.ModifyStudent(stud);

                if (studModified)
                    Console.WriteLine("Student Record Modified Successfully");
                else
                    throw new StudentException("Student Record Not Modified");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteStudent()
        {
            int studID;

            try 
            {
                Console.Write("Enter Student ID of the Student which you would like to delete : ");
                studID = Convert.ToInt32(Console.ReadLine());

                bool studDeleted = StudentValidation.DeleteStudent(studID);

                if (studDeleted)
                    Console.WriteLine("Student Record Deleted Successfully");
                else
                    throw new StudentException("Student Record Not Deleted");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchStudent()
        {
            int studID;

            try 
            {
                Console.Write("Enter Student ID of the Student which you would like to delete : ");
                studID = Convert.ToInt32(Console.ReadLine());

                Student stud = StudentValidation.SearchStudent(studID);

                if (stud != null)
                {
                    Console.WriteLine("Student ID : " + stud.StudentID);
                    Console.WriteLine("Student Name : " + stud.StudentName);
                    Console.WriteLine("Student Date of Birth : " + stud.DOB);
                    Console.WriteLine("Student Phone Number : " + stud.Phone);
                    Console.WriteLine("Student Course : " + stud.Course);
                }
                else
                {
                    throw new StudentException("Student not found with ID : " + studID);
                }
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveStudent()
        {
            List<Student> studList = null;

            try 
            {
                studList = StudentValidation.RetrieveStudent();

                if (studList.Count > 0)
                {
                    Console.WriteLine("********************************************************************************************");
                    Console.WriteLine("------------------------------------Student Information-------------------------------------");
                    Console.WriteLine("Student ID \t Student Name \t\t Student Date of Birth \t Phone Number \t Course");
                    Console.WriteLine("********************************************************************************************");
                    foreach (Student s in studList)
                    {
                        Console.WriteLine(s.StudentID + "\t" + s.StudentName + "\t\t" + s.DOB + "\t" + s.Phone + "\t" + s.Course);
                    }
                    Console.WriteLine("********************************************************************************************");
                }
                else
                    throw new StudentException("Student Records not Available");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeStudent()
        {
            try 
            {
                bool studSerialized = StudentValidation.SerializeStudent();

                if (studSerialized)
                    Console.WriteLine("Student Records Serialized");
                else
                    throw new StudentException("Student Records not Serialized");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeStudent()
        {
            List<Student> studList = null;

            try 
            {
                studList = StudentValidation.DeserializeStudent();

                if (studList.Count > 0)
                {
                    Console.WriteLine("********************************************************************************************");
                    Console.WriteLine("------------------------------------Student Information-------------------------------------");
                    Console.WriteLine("Student ID \t Student Name \t\t Student Date of Birth \t Phone Number \t Course");
                    Console.WriteLine("********************************************************************************************");
                    foreach (Student s in studList)
                    {
                        Console.WriteLine(s.StudentID + "\t" + s.StudentName + "\t\t" + s.DOB + "\t" + s.Phone + "\t" + s.Course);
                    }
                    Console.WriteLine("********************************************************************************************");
                }
                else
                    throw new StudentException("Student Records not Deserialized");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("****************************");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Modify Student");
            Console.WriteLine("3. Delete Student");
            Console.WriteLine("4. Search Student");
            Console.WriteLine("5. Retrieve Student");
            Console.WriteLine("6. Serialize Student");
            Console.WriteLine("7. Deserialize Student");
            Console.WriteLine("8. Exit");
            Console.WriteLine("****************************");
        }
        
        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddStudent();
                            break;
                        case 2: ModifyStudent();
                            break;
                        case 3: DeleteStudent();
                            break;
                        case 4: SearchStudent();
                            break;
                        case 5: RetrieveStudent();
                            break;
                        case 6: SerializeStudent();
                            break;
                        case 7: DeserializeStudent();
                            break;
                        case 8: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Wrong Choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
