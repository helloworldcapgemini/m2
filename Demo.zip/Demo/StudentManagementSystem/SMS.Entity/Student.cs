﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    /// <summary>
    /// Employee ID : 
    /// Employee Name : 
    /// Description : This is an Entity class for Student Information
    /// Date of Creation : 16-Oct-2017
    /// </summary>
    [Serializable]
    public class Student
    {
        //Get or Set Student ID
        public int StudentID { get; set; }
        //Get or Set Student Name
        public string StudentName { get; set; }
        //Get or Set Date of Birth
        public DateTime DOB { get; set; }
        //Get or Set Phone Number
        public string Phone { get; set; }
        //Get ot Set Course
        public string Course { get; set; }
    }
}
