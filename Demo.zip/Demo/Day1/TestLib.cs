using System;
using UtilityMethods;

public class Program
{
	public static void Main(string[] args)
	{
		if(args.Length != 2)
		{
			Console.WriteLine("Please provide 2 arguments like : TestLib num1 num2");
		}
		else
		{
			int num1 = int.Parse(args[0]);
			int num2 = int.Parse(args[1]);

			int sum = AddClass.Add(num1, num2);
			int mult = MultClass.Multiply(num1, num2);

			Console.WriteLine("Addition of " + num1 + " & " + num2 + " is : " + sum);
			Console.WriteLine("Multiplication of " + num1 + " & " + num2 + " is : " + mult);
		}
	}
}