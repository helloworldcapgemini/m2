﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;

namespace MathApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            int num1, num2;

            Console.Write("Enter Num1 : ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter Num2 : ");
            num2 = int.Parse(Console.ReadLine());

            int sum = Calculate.Add(num1, num2);
            int sub = cal.Subtract(num1, num2);
            int mult = cal.Multiply(num1, num2);
            int div = Calculate.Divide(num1, num2);

            Console.WriteLine("Addition of {0} and {1} is : {2}", num1, num2, sum);
            Console.WriteLine("Subtraction of {0} and {1} is : {2}", num1, num2, sub);
            Console.WriteLine("Multiplication of {0} and {1} is : {2}", num1, num2, mult);
            Console.WriteLine("Division of {0} and {1} is : {2}", num1, num2, div);

            Console.ReadKey();
        }
    }
}
