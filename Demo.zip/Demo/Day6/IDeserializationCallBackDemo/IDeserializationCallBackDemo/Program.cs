﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IDeserializationCallBackDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product(101, "NoteBook", 40, 6);

            FileStream fs = new FileStream("Product.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, p);
            fs.Close();
            Console.WriteLine("Serialization Complete");

            fs = new FileStream("Product.txt", FileMode.Open, FileAccess.Read);
            Product prod = (Product)bin.Deserialize(fs);
            fs.Close();
            
            Console.WriteLine("Product ID : " + prod.ProductID);
            Console.WriteLine("Product Name : " + prod.ProductName);
            Console.WriteLine("Product Price : " + prod.Price);
            Console.WriteLine("Product Quantity : " + prod.Quantity);
            Console.WriteLine("Product Total Price : " + prod.TotalPrice);

            Console.ReadKey();
        }
    }
}
