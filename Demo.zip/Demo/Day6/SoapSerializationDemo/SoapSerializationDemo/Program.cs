﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace SoapSerializationDemo
{
    [Serializable]
    public class Employee
    {
        int empID;
        string name;
        double sal;

        public int EmployeeID 
        {
            get { return empID; }
            set { empID = value; }
        }

        public string EmployeeName
        { 
            get { return name; }
            set { name = value; }
        }

        public double Salary 
        {
            get { return sal; }
            set { sal = value; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { EmployeeID = 101, EmployeeName = "Robert", Salary = 30000 };

            FileStream fs = new FileStream("Employee.soap", FileMode.Create, FileAccess.Write);

            SoapFormatter soap = new SoapFormatter();

            soap.Serialize(fs, emp);

            fs.Close();

            Console.WriteLine("Serialization Done");

            fs = new FileStream("Employee.soap", FileMode.Open, FileAccess.Read);
            Employee empOther = (Employee)soap.Deserialize(fs);
            fs.Close();
            Console.WriteLine("Employee ID : " + empOther.EmployeeID);
            Console.WriteLine("Employee Name : " + empOther.EmployeeName);
            Console.WriteLine("Employee Salary : " + empOther.Salary);

            Console.ReadKey();
        }
    }
}
