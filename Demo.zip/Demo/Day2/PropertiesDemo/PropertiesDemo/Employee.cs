﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    public class Employee
    {
        int empID;

        public int EmployeeID
        {
            get { return empID; }
            set { empID = value; }
        }

        string name;

        public string EmployeeName 
        {
            get { return name; }
            set { name = value; }
        }

        double sal;

        public double Salary 
        {
            get { return sal; }
            set { sal = value; }
        }

        string city;
        public string City 
        {
            get { return city; }
            set { city = value; }
        }
    }
}
