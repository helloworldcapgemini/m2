﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverloadingDemo
{
    class Program
    {
        public static void Add(int num1, int num2)
        {
            Console.WriteLine("{0} + {1} => {2}", num1, num2, (num1 + num2));
        }

        //public static int Add(int num1, int num2)
        //{
        //    return num1 + num2;
        //}

        public static void Add(int num1, int num2, int num3)
        {
            Console.WriteLine("{0} + {1} + {2} => {3}", num1, num2, num3, (num1 + num2 + num3));
        }

        public static void Add(float num1, float num2)
        {
            Console.WriteLine("{0} + {1} => {2}", num1, num2, (num1 + num2));
        }

        public static void Add(int num1, float num2)
        {
            Console.WriteLine("{0} + {1} => {2}", num1, num2, (num1 + num2));
        }

        public static void Add(float num1, int num2)
        {
            Console.WriteLine("{0} + {1} => {2}", num1, num2, (num1 + num2));
        }

        static void Main(string[] args)
        {
            Add(12, 45);
            Add(12, 23, 34);
            Add(23.54f, 12);
            Add(45.23f, 56.76f);
            Add(12, 67.45f);

            Console.ReadKey();
        }
    }
}
