﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo
{
    public class Employee
    {
        static Employee()
        {
            Console.WriteLine("Static Constructor for Employee Class");
        }

        public Employee()
        {
            Console.WriteLine("Default Constructor for Employee Class");
        }

        public Employee(int id)
        {
            Console.WriteLine("Parameterized Constructor with 1 Parameter for Employee Class");
        }

        public Employee(int id, string name)
        {
            Console.WriteLine("Parameterized Constructor with 2 Parameters for Employee Class");
        }

        public static void Show()
        {
            Console.WriteLine("Show Method");
        }
    }
}
