﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypedDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //var num;    //Error : Implicitly Typed Local Variable Must be Initialized
            var num = 120;
            Console.WriteLine("Type of Num : " + num.GetType());

            //num = ".NET";   //Error : Cannot implicitly convert type string to int

            //var str = null; //Error : Cannot assign null to implicitly typed local variable
            var str = ".NET";
            str = null;

            //var arr = { 12, 13, 14, 15 }; //Error : Cannot initialize with an array initializer
            var arr = new int[] { 12, 13, 14, 15 };
        }
    }
}
