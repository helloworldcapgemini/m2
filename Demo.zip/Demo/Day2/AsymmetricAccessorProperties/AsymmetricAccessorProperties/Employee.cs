﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsymmetricAccessorProperties
{
    public class Employee
    {
        int empID;

        public int EmployeeID 
        {
            get { return empID; }
            private set { empID = value; }
        }
    }
}
