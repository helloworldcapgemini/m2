﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            char[][] names = new char[5][];

            for (int i = 0; i < names.GetLength(0); i++)
            {
                int size;
                Console.WriteLine("Enter the number of characters from name " + (i + 1));
                size = Convert.ToInt32(Console.ReadLine());

                names[i] = new char[size];
                Console.WriteLine("Enter name : ");
                for (int j = 0; j < names[i].Length; j++)
                {
                    names[i][j] = Convert.ToChar(Console.ReadLine());
                }
            }

            Console.WriteLine("Names Are : ");
            for (int i = 0; i < names.GetLength(0); i++)
            {
                for (int j = 0; j < names[i].Length; j++)
                {
                    Console.Write(names[i][j]);
                }
                Console.WriteLine();
            }
        }
    }
}
