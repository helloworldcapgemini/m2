﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttributeDemo
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Field|AttributeTargets.Method)]
    public class AuthorAttribute : Attribute
    {
        string name;

        public AuthorAttribute(string name)
        {
            this.name = name;
        }

        public string AuthorName { get { return name; } }

    }
}
