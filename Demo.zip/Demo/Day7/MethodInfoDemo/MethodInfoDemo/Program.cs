﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly reflection = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type calculate = reflection.GetType("ReflectionLibrary.Calculate");

            MethodInfo[] calMethods = calculate.GetMethods();

            foreach (MethodInfo m in calMethods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Contains Generic Parameter : " + m.ContainsGenericParameters);
                Console.WriteLine("Is Abstract : " + m.IsAbstract);
                Console.WriteLine("Is Constructor : " + m.IsConstructor);
                Console.WriteLine("Is Final : " + m.IsFinal);
                Console.WriteLine("Is Generic Method : " + m.IsGenericMethod);
                Console.WriteLine("Is Private : " + m.IsPrivate);
                Console.WriteLine("Is Public : " + m.IsPublic);
                Console.WriteLine("Is Static : " + m.IsStatic);
                Console.WriteLine("Is Virtual : " + m.IsVirtual);
                Console.WriteLine("Return Parameter : " + m.ReturnParameter);
                Console.WriteLine("Return Type : " + m.ReturnType.Name);
                ParameterInfo[] param = m.GetParameters();
                Console.WriteLine("Number of Parameters : " + param.Length);
                Console.WriteLine("Parameter Information : ");
                foreach (ParameterInfo p in param)
                {
                    Console.WriteLine("*********Parameter Name : " + p.Name);
                    Console.WriteLine("\tParameter Type : " + p.ParameterType.Name);
                }
                Console.WriteLine("**************************************************************************");
            }

            MethodInfo add = calculate.GetMethod("Add");
            int sum = (int)add.Invoke(null, new object[] { 23, 56 });
            Console.WriteLine("Addition is : " + sum);

            object cal = reflection.CreateInstance("ReflectionLibrary.Calculate");
            MethodInfo sub = calculate.GetMethod("Subtract");
            int result = (int)sub.Invoke(cal, new object[] { 65, 12 });
            Console.WriteLine("Subtraction is : " + result);
            Console.ReadKey();
        }
    }
}
