﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PropertyInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly reflection = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type employee = reflection.GetType("ReflectionLibrary.Employee");

            PropertyInfo[] props = employee.GetProperties();

            foreach (PropertyInfo p in props)
            {
                Console.WriteLine("Property Name : " + p.Name);
                Console.WriteLine("Can Read : " + p.CanRead);
                Console.WriteLine("Can Write : " + p.CanWrite);
                Console.WriteLine("Property Type Name : " + p.PropertyType.Name);
                Console.WriteLine("*******************************************");
            }

            PropertyInfo id = employee.GetProperty("EmployeeID");
            object emp = reflection.CreateInstance("ReflectionLibrary.Employee");
            id.SetValue(emp, 101);

            Console.WriteLine("Employee ID : " + id.GetValue(emp));
        }
    }
}
