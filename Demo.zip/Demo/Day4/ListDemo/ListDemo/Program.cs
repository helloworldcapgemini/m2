﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListDemo
{
    public class Customer
    {
        public int CustID { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList = new List<int>();

            intList.Add(12);
            intList.Add(34);
            intList.Add(45);

            List<Customer> custList = new List<Customer>();

            custList.Add(new Customer() { CustID = 1, Name = "Ritika", City = "Mumbai" });


        }
    }
}
