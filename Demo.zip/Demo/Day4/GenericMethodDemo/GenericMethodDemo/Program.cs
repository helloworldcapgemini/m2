﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethodDemo
{
    class Program
    {
        public void Swap<T>(T val1, T val2)
        {
            T temp = val1;
            val1 = val2;
            val2 = temp;
        }

        static void Main(string[] args)
        {
            Program p = new Program();

            p.Swap<int>(10, 20);

        }
    }
}
