﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodDemo
{
    public delegate void AnonymousWithoutParamDel();

    public delegate void AnonymousWithParamDel(int num1, int num2);

    class Program
    {
        public static void Show()
        {
            Console.WriteLine("Show Method called using Delegate");
        }

        static void Main(string[] args)
        {
            //calling Method using Delegate 
            AnonymousWithoutParamDel del = new AnonymousWithoutParamDel(Show);
            del();

            //Calling Anonymous method using Delegate
            //AnonymousWithoutParamDel an = new AnonymousWithoutParamDel(delegate 
            //    { 
            //        Console.WriteLine("Anonymous Method called using Delegate"); 
            //    });

            AnonymousWithoutParamDel an = delegate
            {
                Console.WriteLine("Anonymous Method called using Delegate");
            };
            an();

            AnonymousWithParamDel anParam = delegate(int num1, int num2) 
            {
                Console.WriteLine("{0} + {1} => {2}", num1, num2, (num1 + num2));
            };

            anParam(23, 67);

            Console.ReadKey();
        }
    }
}
