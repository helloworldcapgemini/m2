﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
   abstract class Employee
    {

       protected int id;
       protected string name;
      protected  string address;
       protected string city;
       protected string department;
      protected double salary;

        public Employee(int id, string name, string address, string city, string department, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.city = city;
            this.department = department;
            this.salary = salary;
        }
        public abstract void getSalary();
        
        public virtual void printdetails()
        {
            Console.WriteLine("Employee id:" + id);
            Console.WriteLine("Employee name:" + name);
            Console.WriteLine("Employee address:" + address);
            Console.WriteLine("Employee city:" + city);
            Console.WriteLine("Employee department:" + department);
            Console.WriteLine("Employee basic salary:" + salary);
        }

    }

    class ContractEmployee : Employee
    {
        double perks;
        public ContractEmployee(int id, string name, string address, string city, string department, double salary, double perks)
            : base(id, name, address, city, department, salary)
        {
            this.perks = perks;
        }
        public override void getSalary()
        {
            salary = salary + perks;
            Console.WriteLine("Net Salary:" + salary);
        }
        public override void printdetails()
        {
            base.printdetails();
            Console.WriteLine("Employee perks:" + perks);
        }
    }

    class PermanentEmployee:Employee
    {
        int no_of_leaves;
        double pf;

        public PermanentEmployee(int id, string name, string address, string city, string department, double salary, double pf,int no_of_leaves)
            :base(id,name,address,city,department,salary)
        {
            this.pf = pf;
            this.no_of_leaves = no_of_leaves;
        }
        public override void getSalary()
        {
            salary = salary - pf;
            Console.WriteLine("Net Salary:" + salary);
        }
        public override void printdetails()
        {
            base.printdetails();
            Console.WriteLine("Employee perks:" + pf);
        }

    }
}
