﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e;
            Console.WriteLine("Enter\n1:Contract Employee\n2:Permanent Employee");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the id");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the address");
            string address = Console.ReadLine();
            Console.WriteLine("Enter the city");
            string city = Console.ReadLine();
            Console.WriteLine("Enter the department");
            string department = Console.ReadLine();
            Console.WriteLine("Enter the salary");
            double salary = double.Parse(Console.ReadLine());
            if(a==1)
            {
                
               Console.WriteLine("Enter the perks");
               double perks = double.Parse(Console.ReadLine());
               e = new ContractEmployee(id, name, address, city, department, salary, perks);
               e.printdetails();
               e.getSalary();
            }
            else if(a==2)
            {
                Console.WriteLine("Enter the pf");
                double pf = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the no_of_leaves");
                int no_of_leaves = int.Parse(Console.ReadLine());
                e = new PermanentEmployee(id, name, address, city, department, salary, pf, no_of_leaves);
                e.printdetails();
                e.getSalary();

            }
            Console.ReadKey();

        }
    }
}
