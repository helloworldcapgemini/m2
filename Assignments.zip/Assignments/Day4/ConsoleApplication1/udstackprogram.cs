﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class udstackprogram
    {
        static void swap<T>(ref T n1,ref T n2)
        {
            T t = n1;
            n1 = n2;
            n2 = t;
        }
        static void ADDsub(int n1,int n2,out int add,out int sub)
        {
            add = n1 + n2;
            sub = n1 - n2;
        }
        static void ShowNames(params string[] names)
        {
            foreach(var nm in names)
            {
                Console.WriteLine(nm);
            }
        }
        static void Main(string[] args)
        {
            //UDStack<int> s1 = new UDStack<int>(3);
            //s1.push(101);
            //s1.push(102);
            //s1.push(103);

            //for(int i=0;i<3;i++)
            //{
            //    Console.WriteLine(s1.pop());
            //}
            string[] names = { "Babita", "Sumit", "Monika" };
            //ShowNames(names);
            ShowNames("Babita", "Sumit", "Monika");
            //int n1 = 10; int n2 = 20;
            //int add, sub;
            //swap<int>(ref n1, ref n2);
            //string S1 = "hELLO";
            //string S2 = "hEY";
            //swap<string>(ref S1, ref S2);
            //ADDsub(n1, n2,out add,out sub);
            //Console.WriteLine("addition:" + add+"\t" + "sub:" + sub);
            //Console.WriteLine("n1=" + n1 +"\t"+ "n2=" + n2+ "\t" + "s1=" + S1 +"\t" + "s2=" + S2);
            Console.ReadKey();
        }
      
        
    }
}
