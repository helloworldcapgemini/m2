﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using EMS_Entities;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> s1=new Stack<int>();
            s1.Push(10);
            s1.Pop();
            Dictionary<int,Employee> dict=new Dictionary<int,Employee>();
            Employee e1=new Employee(){Id=101,Name="kamlesh"};
            dict.Add(e1.Id,e1);
            for(int i=0;i<10;i++)
            {
                Employee e=new Employee(){Id=102+i,Name="Name"+(101+i)};
                    dict.Add(e.Id,e);
            }
            foreach (var item in dict)
	        {
		       Console.WriteLine(item.Value.Id+"\t"+item.Value.Name);
	        }
            Console.ReadKey();
        }
    }
}
