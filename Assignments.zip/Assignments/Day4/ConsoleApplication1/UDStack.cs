﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class UDStack<T> 
    {
        int pos;
        T[] items = null;
        public UDStack(int size)
        {
            pos = -1;
            items = new T[size];
        }
       public void push(T item)
        {
           pos++;
           items[pos] = item;
        }
        public object pop()
       {
           return items[pos--];
       }
    }
}
