﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB5
{
    public enum BankAccountType
    {
        Current = 1,
        Saving = 2
    }
   abstract class BankAccount:IBankAccount
    {
        protected double balance;
        public abstract double GetBalance();
        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }
        public abstract void CalculateInterest();

      public  BankAccountType AccountType { get; set; } 

    }
}
