﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB5
{
    class ICICI:BankAccount
    {
        
        public override double  GetBalance()
        {
            return balance;
        }
        public override bool Withdraw(double amount)
        {
            if (balance > 0)
            {
                balance = balance - amount;
                return true;
            }
            else
                return false;
        }
        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            if(((balance)-amount)>1000)
            {
                toAccount.Deposit(amount);
                balance=balance-amount;
                return true;

            }
            else
                return false;
        }
        public override void CalculateInterest()
        {
            double interest = 0.07 * balance;
            Console.WriteLine("Interest of 1 year:" + interest);
        }


    }
}
