﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB5
{
    class Program
    {
        static void Main(string[] args)
        {
            ICICI i1 = new ICICI();
            i1.AccountType = BankAccountType.Saving;
            i1.Deposit(50000);
            ICICI i2 = new ICICI();
            i2.AccountType = BankAccountType.Current;
            i2.Deposit(20000);
            Console.WriteLine("Balance of class 1:" + i1.GetBalance());
            Console.WriteLine("Balance of class 2:" + i2.GetBalance());
            i1.Transfer(i2,5000);
            Console.WriteLine("Balance after transfer 5000");
            Console.WriteLine("Balance of class 1:" + i1.GetBalance());
            Console.WriteLine("Balance of class 2:" + i2.GetBalance());
            i1.CalculateInterest();
            i2.CalculateInterest();

            Console.WriteLine("For HSBC ACCOUNT");
            HSBC h1 = new HSBC();
            h1.AccountType = BankAccountType.Saving;
            h1.Deposit(50000);
            HSBC h2 = new HSBC();
            h2.AccountType = BankAccountType.Current;
            h2.Deposit(45000);

            Console.WriteLine("Balance of class 1:" + h1.GetBalance());
            Console.WriteLine("Balance of class 2:" + h2.GetBalance());

            h1.Transfer(h2, 30000);
            Console.WriteLine("Balance after transfer 30000");
            Console.WriteLine("Balance of class 1:" + h1.GetBalance());
            Console.WriteLine("Balance of class 2:" + h2.GetBalance());
            h1.CalculateInterest();
            h2.CalculateInterest();

            Console.ReadKey();

        }
    }
}
