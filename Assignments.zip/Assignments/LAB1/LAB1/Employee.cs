﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB1
{
    class Employee
    {
        int id;
        string name;
        string address;
        string city;
        string department;
        double salary;

        public void Setdetails(int id, string name, string address, string city, string department, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.city = city;
            this.department = department;
            this.salary = salary;
        }
        public void printdetails()
        {
            Console.WriteLine("Employee id:" + id);
            Console.WriteLine("Employee name:" + name);
            Console.WriteLine("Employee address:" + address);
            Console.WriteLine("Employee city:" + city);
            Console.WriteLine("Employee department:" + department);
            Console.WriteLine("Employee salary:" + salary);
        }
        public int id_details
        {
            get { return id; }
            set { id = value; }
        }
        public string name_details
        {
            get { return name; }
            set { name = value; }
        }
        public string address_details
        {
            get { return address; }
            set { address = value; }
        }
        public string city_details
        {
            get { return city; }
            set { city = value; }
        }
        public string department_details
        {
            get { return department; }
            set { department = value; }
        }
        public double salary_details
        {
            get { return salary; }
            set { salary = value; }
        }
        
    }
}
