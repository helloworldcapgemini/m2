﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB1
{
    class Program
    {
        static void Main(string[] args)
        {
            int id,i;
            string name, address, city, department;
            double salary;

//task1    // Employee e1 = new Employee();
           // Console.WriteLine("Enter the id");
           //  id = int.Parse(Console.ReadLine());
           // Console.WriteLine("Enter the name");
           //  name = Console.ReadLine();
           // Console.WriteLine("Enter the address");
           //  address = Console.ReadLine();
           // Console.WriteLine("Enter the city");
           //city = Console.ReadLine();
           // Console.WriteLine("Enter the department");
           //  department = Console.ReadLine();
           // Console.WriteLine("Enter the salary");
           //  salary = double.Parse(Console.ReadLine());
           // e1.Setdetails(id, name, address, city,department, salary);
           // e1.printdetails();


 //task 2  //Employee[] emp = new Employee[10];
            //for ( i = 0; i < emp.Length-7; i++)
            //{
            //    emp[i] = new Employee();
            //    Console.WriteLine("Enter the id");
            //    id = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Enter the name");
            //    name = Console.ReadLine();
            //    Console.WriteLine("Enter the address");
            //    address = Console.ReadLine();
            //    Console.WriteLine("Enter the city");
            //    city = Console.ReadLine();
            //    Console.WriteLine("Enter the department");
            //    department = Console.ReadLine();
            //    Console.WriteLine("Enter the salary");
            //    salary = double.Parse(Console.ReadLine());
            //    emp[i].Setdetails(id, name, address, city, department, salary);
               
            //}

            //for ( i = 0; i < emp.Length-7; i++)
            //{
            //    emp[i].printdetails();

            //}


            Console.WriteLine("Enter the id");
            id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the address");
            address = Console.ReadLine();
            Console.WriteLine("Enter the city");
            city = Console.ReadLine();
            Console.WriteLine("Enter the department");
            department = Console.ReadLine();
            Console.WriteLine("Enter the salary");
            salary = double.Parse(Console.ReadLine());
            Employee e2 = new Employee();
            e2.id_details = id;
            e2.name_details = name;
            e2.address_details = address;
            e2.city_details = city;
            e2.department_details = department;
            e2.salary_details = salary;

            Console.WriteLine(e2.id_details);
            Console.WriteLine(e2.name_details);
            Console.WriteLine(e2.address_details);
            Console.WriteLine(e2.city_details);
            Console.WriteLine(e2.department_details);
            Console.WriteLine(e2.salary_details);
            Console.ReadKey();
            
             

        }
    
    }
}
