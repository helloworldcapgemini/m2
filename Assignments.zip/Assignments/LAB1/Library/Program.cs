﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            arithmatic_calculator ab = new arithmatic_calculator();
            Console.WriteLine("Enter 2 numbers\n add:1\nsubtract:2\nmultiply:3\ndivide:4\nmodulus:5");
            double a, b;
            a = double.Parse(Console.ReadLine());
            b = double.Parse(Console.ReadLine());
            int i = int.Parse(Console.ReadLine());
            switch(i)
            {
                case 1: Console.WriteLine("sum is:" + ab.add(a, b));
                    break;
                case 2: Console.WriteLine("subtraction is:" + ab.subtract(a, b));
                    break;
                case 3: Console.WriteLine("multiply is:" + ab.multiply(a, b));
                    break;
                case 4: Console.WriteLine("divide is:" + ab.divide(a, b));
                    break;
                case 5: Console.WriteLine("modulus is:" + ab.modulus(a, b));
                    break;
            }
            Console.ReadKey();

           
            
            

            

            

            
        

           
            

            
        }
    }
}
