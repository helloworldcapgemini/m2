﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class arithmatic_calculator
    {
        double d1, d2;

        public double add(double d1,double d2)
        {
            return (d1 + d2);
        }
        public double subtract(double d1, double d2)
        {
            return (d1 - d2);
        }

        public double multiply(double d1, double d2)
        {
            return (d1 * d2);
        }
        public double divide(double d1, double d2)
        {
            return (d1 / d2);
        }
        public double modulus(double d1, double d2)
        {
            return (d1 % d2);
        }
       

    }
}
