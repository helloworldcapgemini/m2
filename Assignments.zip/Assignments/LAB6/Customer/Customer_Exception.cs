﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer
{
    class InvalidCreditLimitcustomorException:Exception
    {
        public InvalidCreditLimitcustomorException(string msg):base(msg)
        {

        }
        
    }
}
