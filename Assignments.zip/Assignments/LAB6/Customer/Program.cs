﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer id");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter address");
            string address = Console.ReadLine();
            Console.WriteLine("Enter city");
            string city = Console.ReadLine();
            Console.WriteLine("Enter phone no");
            string phone_no = Console.ReadLine();
            try
            {
                Console.WriteLine("Enter Customer credit_limit");
                int credit_limit = int.Parse(Console.ReadLine());
                if (credit_limit > 50000)
                    throw new InvalidCreditLimitcustomorException("credit limit less than 50000");
            }
            catch(InvalidCreditLimitcustomorException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            Console.ReadKey();
        }
    }
}
