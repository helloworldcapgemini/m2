﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer
{
    class Customer
    {
        int id;
        string name, address, city, phone_no;
        double credit_limit;

        public Customer()
        {

        }
        public Customer(int id,string name,string address,string city,string phone_no,double credit_limit)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.city = city;
            this.phone_no = phone_no;
            this.credit_limit = credit_limit;
        }
        public int cust_id
        {
            get { return id; }
            set { id = value; }
        }
        public string cust_name
        {
            get { return name; }
            set { name = value; }
        }
        public string cust_address
        {
            get { return address; }
            set { address= value; }
        }
        public string cust_city
        {
            get { return city; }
            set { city = value; }
        }
        public string cust_phone
        {
            get { return phone_no; }
            set { phone_no = value; }
        }
        public double cust_credit_limit
        {
            get { return credit_limit; }
            set { credit_limit = value; }
        }


    }
}
