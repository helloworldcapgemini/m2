﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class product
    {
        int product_id;
        string product_name;
        double price;

        public int Product_Id 
        {
            get { return product_id; }
            set {
                product_id = value; 
            }
        }
        public string Product_name
        {
            get { return product_name; }
            set { product_name = value; }
        }
        public double Product_price
        {
            get { return price; }
            set {price = value; }
        }
    }
}
