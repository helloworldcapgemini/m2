﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            product p = new product();
            try
            {
                Console.WriteLine("enter product id");
                int id = int.Parse(Console.ReadLine());
                if (id <= 0)
                    throw new dataexception("Product ID must be greater than zero");

                Console.WriteLine("enter product name");
                string name = Console.ReadLine();
                if(name=="")
                    throw new dataexception("Product Name cannot be left blank");

                Console.WriteLine("enter product price");
                double price = double.Parse(Console.ReadLine());
                if(price<=0)
                    throw new dataexception("Price of product must be greater than zero.");

            }
            catch(dataexception ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            Console.ReadKey();
        }
    }
}
