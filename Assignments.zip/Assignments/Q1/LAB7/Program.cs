﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB7
{
    class Program
    {
        static List<ContactList> cl = new List<ContactList>();
        static void AddContact()
        {
            ContactList c = new ContactList();
            Console.WriteLine("Enter contact number");
            c.ContactNo = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter contact name");
            c.ContactName = Console.ReadLine();
            Console.WriteLine("Enter cell number");
            c.CellNo = Console.ReadLine();

            cl.Add(c);


        }
        static void ShowAllContacts()
        {
            cl.Sort();
            foreach (var item in cl)
            {
                item.printdetails();
            }
        }
        static void DisplayContact()
        {
            int n;
            Console.WriteLine("Enter the contact number");
            n = int.Parse(Console.ReadLine());
            foreach (var item in cl)
            {
                if (item.ContactNo == n)
                {
                    item.printdetails();
                }
            }
        }
        static void EditContact()
        {
            int n;
            Console.WriteLine("Enter the contact number");
            n = int.Parse(Console.ReadLine());
            foreach (var item in cl)
            {
                if (item.ContactNo == n)
                {     
                    Console.WriteLine("Enter new contact number");
                    item.ContactNo = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter new contact name");
                    item.ContactName = Console.ReadLine();
                    Console.WriteLine("Enter new cell number");
                    item.CellNo = Console.ReadLine();
                }
            }
        }

        static void Main(string[] args)
        {

            int n = 1;
            while (n == 1)
            {
                Console.WriteLine("Enter \n1.To add contact detail to List");
                Console.WriteLine("2.To display particular contact detail from List");
                Console.WriteLine("3.To modiy particular contact detail from List");
                Console.WriteLine("4.To display all contact details from List");
                Console.WriteLine("5. Quit the Program");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            AddContact();
                            break;
                        }
                    case 2:
                        {
                            DisplayContact();
                            break;
                        }
                    case 3:
                        {
                            EditContact();
                            break;
                        }
                    case 4:
                        {
                            ShowAllContacts();
                            break;
                        }
                    case 5:
                        return;
                        break;
                    default: Console.WriteLine("Enter correct option");
                        break;
                }
            }

        }
    }
}
