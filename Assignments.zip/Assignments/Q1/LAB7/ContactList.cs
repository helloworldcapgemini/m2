﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB7
{
    class ContactList
    {

        public  int ContactNo { get; set; }
        public string ContactName { get; set; }
        public string CellNo { get; set; }

        public void printdetails()
        {
            Console.WriteLine("ContactNo:" + ContactNo);
            Console.WriteLine("ContactName:" +ContactName);
            Console.WriteLine("CellNo:" + CellNo);
        }
    }
}
