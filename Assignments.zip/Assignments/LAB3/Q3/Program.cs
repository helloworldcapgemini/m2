﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            List < Car > carlist= new List<Car>();
            Car c1=null;
            int n;
            int ch=0;
            do
            {
                Console.WriteLine("Enter number");
                Console.WriteLine("1:Add a car");
                Console.WriteLine("2:Modify the details of a particular car");
                Console.WriteLine("3:Search for a particular car in the Catalog");
                Console.WriteLine("4:List all the cars in the Catalog");
                Console.WriteLine("5:Delete a car from the Catalog");
                Console.WriteLine("6:Quit");
                n = int.Parse(Console.ReadLine());
                switch(n)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter car Make");
                            string make=Console.ReadLine();
                             Console.WriteLine("Enter car Model");
                            string model=Console.ReadLine();
                            Console.WriteLine("Enter year");
                            int year= int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter price");
                            double price= double.Parse(Console.ReadLine());

                            Car c = new Car(make, model, year, price);
                            carlist.Add(c);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the car make to be search");
                            string match = Console.ReadLine();
                            int flag=0;
                            foreach(Car c in carlist)
                            {
                                if(c.carmake==match)
                                {
                                    flag=1;
                                    Console.WriteLine("Enter new car make");
                                    c.carmake = Console.ReadLine();
                                    Console.WriteLine("Enter new car model");
                                    c.carmodel = Console.ReadLine();
                                    Console.WriteLine("Enter new car year");
                                    c.caryear = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter new car price");
                                    c.carprice = double.Parse(Console.ReadLine());

                                }
                                
                            }
                            if(flag==0)
                            { Console.WriteLine("Car Make not Found"); }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the car make to be search");
                             string match= Console.ReadLine();
                            int flag=0;
                            foreach(Car c in carlist)
                            {
                                if(c.carmake==match)
                                {
                                    flag=1;
                                    c1=c;
                                }
                            }
                            if(flag==0)
                            {Console.WriteLine("Car Make not Found");}
                            else
                            {
                                Console.WriteLine("Car Details are");
                                c1.CarDetails();
                            }
                            break;

                        }
                    case 4:
                        {
                            foreach(Car c in carlist)
                            {
                                c.CarDetails();
                            }
                            break;
                        }
                    case 5:
                            {
                                Console.WriteLine("Enter the car make to be deleted");
                             string match= Console.ReadLine();
                                int flag=0;
                                for (int i = carlist.Count - 1; i >= 0; i--)
                                {
                                    if (carlist[i].carmake == match)
                                    {
                                        flag = 1;
                                        carlist.RemoveAt(i);
                                    }
                                }
                                if(flag==0)
                                {
                                    Console.WriteLine("Car Make not Found");
                                }
                                else
                                {
                                    Console.WriteLine("Successfully deleted");
                                }
                                break;


                }
                    case 6: break;
                    default:break;
                }
                
                Console.WriteLine("Do you want to continue prss 1");
                ch=int.Parse(Console.ReadLine());

            } while (ch == 1);
        }
    }
}
