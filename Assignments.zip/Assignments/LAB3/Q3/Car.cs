﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    public class Car
    {
       string make,model;
      
        int year;
        double price;

        public Car(string make,string model,int year,double price)
        {
            this.make = make;
            this.model = model;
            this.year = year;
            this.price = price;
        }

        public void CarDetails()
        {
            Console.WriteLine("Car Make:"+make);
            Console.WriteLine("Car Model:"+model);
            Console.WriteLine("Car Year:"+year);
            Console.WriteLine("Car Price:"+price);
            Console.WriteLine();
        }
        public string carmake
        {
            get { return make; }
            set { make = value; }
        }
        public string carmodel
        {
            get { return model; }
            set { model = value; }
        }
        public int caryear
        {
            get { return year; }
            set { year = value; }
        }
        public double carprice
        {
            get { return price; }
            set { price = value; }
        }
        

    
    }
    
}
