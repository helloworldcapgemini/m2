﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            double percentage;
            Console.WriteLine("Enter Emp id");
            int id=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Emp name");
            string ename=Console.ReadLine();
            Console.WriteLine("Enter foundation marks");
            int fm=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Dot Net marks");
            int dn=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter webbasic marks");
            int wbm=int.Parse(Console.ReadLine());


            Participant p1 = new Participant(id, ename, fm, dn, wbm);
            p1.Total();
            percentage = p1.per();
            Console.WriteLine("Percentage is :"+percentage+"%");
            Console.ReadKey();
        }
    }
}
