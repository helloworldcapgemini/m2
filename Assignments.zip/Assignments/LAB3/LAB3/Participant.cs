﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Participant
    {
        int empid, TotalMarks, ObtainedMarks, foundationMarks, DotNetMarks,webbasic;
        public int FoundationMarks
        {
            get { return foundationMarks; }
            set
            {

                if (value < 0 || value > 100)
                    value = 0;
                else
                    foundationMarks = value;
            }

        }
        public int dotNetMarks
        {
            get { return DotNetMarks; } 
            set
            {
                if (value < 0 || value > 100)
                    value = 0;
                else
                    DotNetMarks = value;

            } 
        }
        public int Webbasic
        {
            get { return webbasic; }
          set
          {
              if (value < 0 || value > 100)
                  value = 0;
              else
                  webbasic = value;

          }
        }
        string empname;

        static string  company_name;
        double percentage;

        public Participant()
        {
            TotalMarks = 300;
        }
        public Participant(int empid,string empname,int foundationMarks,int DotNetMarks,int webbasic)
        {
            this.empid = empid;
            this.empname = empname;
            this.FoundationMarks = foundationMarks;
            this.dotNetMarks = DotNetMarks;
            this.Webbasic=webbasic;
            TotalMarks = 300;
        }
        static Participant()
        {
            company_name = "Corporate Unniversity";
        }

        public void  Total()
        {
            ObtainedMarks=foundationMarks+DotNetMarks+webbasic;
        }
        public double per()
        {
            return (((double)ObtainedMarks / TotalMarks) * 100);
        }
    }
}
