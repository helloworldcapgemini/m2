﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class SupplierText
    {
        static void Main(string[] args)
        {
            Supplier s1 = new Supplier();
            s1.suppliee_details(s1);
            Console.WriteLine(s1);
            Console.ReadKey();
        }
    }
}
