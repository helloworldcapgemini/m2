﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Supplier
    {
        int id;
        string name, city, email, phone;

        public void suppliee_details(Supplier s)
        {
            Console.WriteLine("Enter id");
            s.id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter name");
            s.name = Console.ReadLine();
            Console.WriteLine("Enter city");
            s.city = Console.ReadLine();
            Console.WriteLine("Enter email");
            s.email = Console.ReadLine();
            Console.WriteLine("Enter phone");
            s.phone= Console.ReadLine();


        }
        public override string ToString()
        {
            return "id:" + id + "\n" + "name:" + name + "\n" + "city:" + city + "\n" + "email:" + email + "\n" + "phone:" + "\n" + phone;
        }
    }
    
}
