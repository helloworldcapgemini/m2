﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int[,] a = new int[5, 6];
            for( i=0;i<a.GetLength(0);i++)

            {
                for( j=0;j<a.GetLength(1);j++)
                {
                    a[i, j] = int.Parse(Console.ReadLine());
                } 
            }

            for(i=0;i<a.GetLength(0);i++)
            {
                for(j=0;j<a.GetLength(1);j++)
                {
                    Console.Write(a[i,j]+"\t");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
