﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter number of cities");
            n = int.Parse(Console.ReadLine());
            string[] s1 = new string[n];
            Console.WriteLine("Enter  cities");
        
            for(int i=0;i<s1.Length;i++)
            {
                s1[i] = Console.ReadLine();
            }
            foreach (string s in s1)
            {
                Console.WriteLine(s);
            }
            Console.ReadKey();
                

        }
    }
}
