﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class ProductDemo
    {
        object id;
        object name;
        object price;
        object quantity;
        double payble;

        public ProductDemo(int id,string name,double price,int quantity)
        {
            this.id = id;
            this.name = name;
            this.price = price;
            this.quantity = quantity;
            
        }
        public void payble_amount()
        {
            this.payble=(double)price*(int)quantity;
        }
        public void printdetails()
        {
            Console.WriteLine("Product ID:" + (int)id);
            Console.WriteLine("Product name:" + (string)name);
            Console.WriteLine("Product price:" + (double)price);
            Console.WriteLine("Product quantity:" + (int)quantity);
            Console.WriteLine("Product payble amount:" + (int)payble);
        }
    }
}
