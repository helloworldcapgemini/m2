﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int id, quantity;
            string name;
            double price, payble;
            Console.WriteLine("Enter the id");
            id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the price");
            price = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the quantity");
            quantity = int.Parse(Console.ReadLine());

            ProductDemo p1 = new ProductDemo(id, name, price, quantity);

            p1.payble_amount();
            p1.printdetails();


            Console.ReadKey();
           

        }
    }
}
