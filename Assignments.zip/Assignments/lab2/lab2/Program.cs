﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class Program
    {
        struct note
        {
            public double number;

            public double squre()
            {
                return number * number;
            }
            public double cube()
            {
                return number * number * number;
            }
        }
        static void Main(string[] args)
        {
            note n1;
            Console.WriteLine("Enter the number");
            n1.number = int.Parse(Console.ReadLine());
            Console.WriteLine("Squre is:"+n1.squre());
            
            Console.WriteLine("cube is:"+n1.cube());
            
            Console.ReadKey();




        }
    }
}
