﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToBeDeleted
{
    class Program
    {
        public enum Department { HR=1, Operation, Admin, Finance, Other }
        public class Employee
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public DateTime DOJ { get; set; }
            public string MobileNo { get; set; }
            public string Gender { get; set; }
            public Department Department { get; set; }
        }
        public static Employee CreateEmployee()
        {
            Employee emp = new Employee();
            Console.WriteLine("Enter Id: ");
            emp.Id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter dept (1.HR, 2.Operation, 3.Admin, 4.Finance, 5.Other)");
            emp.Department = (Department)int.Parse(Console.ReadLine());

            //Console.WriteLine("Enter dept (1.HR, 2.Operation, 3.Admin, 4.Finance, 5.Other)");
            //Department dept = (Department)Enum.Parse(typeof(Department),Console.ReadLine());
            //emp.Department = dept;

            return emp;
        }
        static void Main(string[] args)
        {
            Employee emp = CreateEmployee();
            Console.WriteLine(DateTime.Now.Year);
            Console.WriteLine(DateTime.Now.ToShortDateString());
            Console.WriteLine(DateTime.Now.ToLongTimeString());
            Console.WriteLine(DateTime.Now.ToShortDateString());
            Console.WriteLine(DateTime.Now.ToShortTimeString());
            Console.WriteLine(DateTime.Now.ToString("ddd-MMM-yyy"));

            DateTime dt1 = DateTime.Now;
            DateTime dt2 = dt1.AddDays(-5);
            DateTime dt3 = dt1.AddDays(5);
            Console.WriteLine(dt1+"\n"+dt2+"\n"+dt3);


            DateTime dt;
            string str = "22-10-17";
            dt= DateTime.ParseExact(str, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);
            Console.WriteLine("Day: "+dt.Day+"\tMonth: "+dt.Month+"\tYear: "+dt.Year);


            Console.ReadKey();
        }
    }
}
