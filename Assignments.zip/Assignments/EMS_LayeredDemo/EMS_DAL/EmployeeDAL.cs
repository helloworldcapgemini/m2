﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
using EMS_Entities;
using EMS_Exceptions;

namespace EMS_DAL
{
    public class EmployeeDAL
    {
        //data-Store
        static ArrayList al_Emps = new ArrayList();

        //Select-All-Employee
        public static ArrayList SelectAll()
        {
            return al_Emps;
        }

        //Insert-Employee
        public static bool Insert(Employee emp)
        {
            int l = al_Emps.Count;
            bool EmployeeAdded = false;
            try
            {
                al_Emps.Add(emp);
                if (al_Emps.Count == (l + 1))
                    EmployeeAdded = true;
            }
            catch(Exception ex)
            {
                throw new EmployeeDataException(ex.Message);
            }
            return EmployeeAdded;
        }

        //Update-Employee
        public static bool Update(Employee emp)
        {
            bool EmployeeUpdated = false;
            try
            {
                for(int i=0; i< al_Emps.Count; i++)
                {
                    var dEmp = (Employee)al_Emps[i];
                    if(dEmp.Id == emp.Id)
                    {
                        dEmp.Name = emp.Name;
                        dEmp.MobileNo = emp.MobileNo;
                        dEmp.Gender = emp.Gender;
                        dEmp.DOJ = emp.DOJ;
                        dEmp.Department = emp.Department;
                        EmployeeUpdated = true;
                        break;
                    }
                }
            }
            catch(Exception ex)
            {
                throw new EmployeeDataException(ex.Message);
            }
            return EmployeeUpdated;
        }

        //Delete-Employee
        public static bool Delete(int empId)
        {
            bool EmployeeDeleted = false;
            try
            {
                for (int i = 0; i < al_Emps.Count; i++)
                {
                    var dEmp = (Employee)al_Emps[i];
                    if (dEmp.Id == empId)
                    {
                        //al_Emps.Remove(dEmp);
                        al_Emps.RemoveAt(i);
                        EmployeeDeleted = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new EmployeeDataException(ex.Message);
            }
            return EmployeeDeleted;
        }
    }
}
