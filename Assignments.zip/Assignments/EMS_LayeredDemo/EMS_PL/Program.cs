﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS_Entities;
using EMS_BAL;
using EMS_Exceptions;
using System.Collections;

namespace EMS_PL
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.Write("Select one of the above mentioned Options:\n");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: ListAllEmployees();
                            break;
                    case 2: AddEmployee();
                            break;
                    case 3: UpdateEmployee();
                            break;
                    case 4: DeleteEmployee();
                            break;
                    case 5: return;
                    default: Console.WriteLine("Invalid Choice");
                            break;
                }
            } while (choice != -1);

            Console.ReadKey();
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Employee Data-Base***********");
            Console.WriteLine("1. List All Employees");
            Console.WriteLine("2. Add New Employee");
            Console.WriteLine("3. Update Employee");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");
            Console.WriteLine("******************************************\n");

        }

        private static void DeleteEmployee()
        {
            try
            {
                int deleteEmployeeId;
                Console.WriteLine("Enter Employee Id to Delete:");
                deleteEmployeeId = int.Parse(Console.ReadLine());
                bool EmployeeDeleted = EmployeeBAL.Remove(deleteEmployeeId);
                if (EmployeeDeleted)
                    Console.WriteLine("Employee Deleted");
                else
                    Console.WriteLine("Employee not Deleted");
            }
            catch (EmployeeDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void AddEmployee()
        {
            try
            {
                bool isValidInput = true;
                Employee emp = new Employee();
                Console.WriteLine("Enter Id: ");
                emp.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Name : ");
                emp.Name = Console.ReadLine();
                int count = 0;
                Console.WriteLine("Enter Date of Joining [dd-MM-yy] : ");
                string dateString = Console.ReadLine();
                DateTime date_obj;
                if (DateTime.TryParseExact(dateString, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date_obj))
                {
                    emp.DOJ = DateTime.ParseExact(dateString, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);
                    count++;
                }
                else
                {
                    Console.WriteLine("Incorrect Date Input");
                }
                Console.WriteLine("Enter Mobile Number : ");
                emp.MobileNo = Console.ReadLine();
                Console.WriteLine("Enter Gender (Male, Female) : ");
                emp.Gender = Console.ReadLine();
                Console.WriteLine("Enter Department (1.HR, 2.Operation, 3.Admin, 4.Finance, 5.Other)");
                int dept = int.Parse(Console.ReadLine());
                if (dept >= 1 && dept <= 5)
                {
                    emp.Department = (Department)dept;
                    count++;
                }
                else
                {
                    Console.WriteLine("Incorrect Department Choice Input");
                }
                if (isValidInput = true && count !=0)
                {
                    bool EmployeeAdded = EmployeeBAL.Add(emp);
                    if (EmployeeAdded)
                        Console.WriteLine("Employee Added");
                    else
                        Console.WriteLine("Guest not Added");
                }
                else
                {
                    Console.WriteLine("False Input Data");
                }
            }
            catch (EmployeeDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void UpdateEmployee()
        {
            try
            {
                bool isValidInput = true;
                Employee emp = new Employee();
                Console.WriteLine("Enter Id: ");
                emp.Id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Name : ");
                emp.Name = Console.ReadLine();
                int count = 0;
                Console.WriteLine("Enter Date of Joining [dd-MM-yy] : ");
                string dateString = Console.ReadLine();
                DateTime date_obj;
                if (DateTime.TryParseExact(dateString, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out date_obj))
                {
                    emp.DOJ = DateTime.ParseExact(dateString, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);
                    count++;
                }
                else
                {
                    Console.WriteLine("Incorrect Date Input");
                }
                Console.WriteLine("Enter Mobile Number : ");
                emp.MobileNo = Console.ReadLine();
                Console.WriteLine("Enter Gender (Male, Female) : ");
                emp.Gender = Console.ReadLine();
                Console.WriteLine("Enter Department (1.HR, 2.Operation, 3.Admin, 4.Finance, 5.Other)");
                int dept = int.Parse(Console.ReadLine());
                if (dept >= 1 && dept <= 5)
                {
                    emp.Department = (Department)dept;
                    count++;
                }
                else
                {
                    Console.WriteLine("Incorrect Department Choice Input");
                }
                if (isValidInput = true && count != 0)
                {
                    bool EmployeeUpdated = EmployeeBAL.Modify(emp);
                    if (EmployeeUpdated)
                        Console.WriteLine("Employee Updated");
                    else
                        Console.WriteLine("Guest not Updated");
                }
                else
                {
                    Console.WriteLine("False Input Data");
                }
            }
            catch (EmployeeDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ListAllEmployees()
        {
            try
            {
                ArrayList empList = EmployeeBAL.GetAll();
                if(empList != null)
                {
                    foreach (Employee e in empList)
                    {
                        Console.WriteLine(e.Id);
                        Console.WriteLine(e.Name);
                        Console.WriteLine(e.DOJ);
                        Console.WriteLine(e.MobileNo);
                        Console.WriteLine(e.Gender);
                        Console.WriteLine(e.Department);
                    }
                }
                else
                {
                    Console.WriteLine("Employee list is empty");
                }
            }
            catch (EmployeeDataException ex)
            {
                throw ex;
            }
        }
    }
}

