﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
using EMS_Entities;
using EMS_DAL;
using EMS_Exceptions;


namespace EMS_BAL
{
    public class EmployeeBAL
    {
        public static bool Validate(int empId)
        {
            bool isValid = true;
            if (empId <= 0)
            {
                isValid = false;
                Console.WriteLine("Invalid Employee ID");
            }
            return isValid;
        }
        public static bool Validate(Employee emp)
        {
            bool isValid = true;

            StringBuilder sb = new StringBuilder();
            if(emp.Id <= 0)
            {
                isValid = false;
                sb.Append(Environment.NewLine+"Invalid Employee ID");
            }
            if(emp.Name == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine+"Employee Name Required");
            }
            if(emp.MobileNo.Length < 10)
            {
                isValid = false;
                sb.Append(Environment.NewLine+"Required 10 Digit Contact Number");
            }
            if(emp.Gender != "Male" && emp.Gender != "Female")
            {
                isValid = false;
                sb.Append(Environment.NewLine+"Required Male or Female only");
            }
            if((DateTime.Now - emp.DOJ).TotalDays < 0)
            {
                isValid = false;
                sb.Append(Environment.NewLine+"Date of Joining should not be future date");
            }
            if(isValid == false)
            {
                throw new EmployeeDataException(sb.ToString());
            }
            return isValid;
        }

        public static ArrayList GetAll()
        {
            return EmployeeDAL.SelectAll();
        }

        public static bool Add(Employee emp)
        {
            bool EmployeeAdded = false;
            try
            {
                if (Validate(emp))
                {
                    EmployeeAdded = EmployeeDAL.Insert(emp);
                }
            }
            catch (EmployeeDataException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }  
            return EmployeeAdded;
        }

        public static bool Modify(Employee emp)
        {
            bool EmployeeUpdated = false;
            try
            {
                if (Validate(emp))
                {
                    EmployeeUpdated = EmployeeDAL.Update(emp);
                }
            }
            catch (EmployeeDataException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return EmployeeUpdated;
        }

        public static bool Remove(int empId)
        {
            bool EmployeeDeleted = false;
            try
            {
                if (Validate(empId))
                {
                    EmployeeDeleted = EmployeeDAL.Delete(empId);
                }
            }
            catch (EmployeeDataException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return EmployeeDeleted;
        }
    }
}
