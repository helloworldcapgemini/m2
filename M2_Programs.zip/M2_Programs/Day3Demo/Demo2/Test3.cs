﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Test3
    {
        static void Main(string[] args)
        {
            int f1, f2;
            float res=0;
            Console.WriteLine("Ener f1:");
            f1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ener f2:");
            f2 = int.Parse(Console.ReadLine());
            MyUtility u1 = new MyUtility();
            try
            {
                res = u1.Div(f1, f2);
            }
            catch(DivideByZeroException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch(Exception ex2)
            {
                 Console.WriteLine(ex2.Message);
            }
            
            Console.WriteLine(res);
            Console.ReadKey();


        }
    }
}
