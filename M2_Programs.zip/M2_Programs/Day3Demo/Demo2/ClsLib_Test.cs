﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class MyUtility
    {
        
            public float Div(int f1,int f2)
            {
                float res=0;
                try
                {
                    res = f1 / f2;
                }
                catch(DivideByZeroException ex1)
                {
                    //Console.WriteLine(ex1.Message);
                    throw;
                }
                
                return res;
               
            }
        
    }
}
