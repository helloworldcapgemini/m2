﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    //[Serializable]
    //public class MyException : Exception
    //{
    //    public MyException() { }
    //    public MyException(string message) : base(message) { }
    //    public MyException(string message, Exception inner) : base(message, inner) { }
    //    protected MyException(
    //      System.Runtime.Serialization.SerializationInfo info,
    //      System.Runtime.Serialization.StreamingContext context)
    //        : base(info, context) { }
    //}
    class Demo2ValidationException : MyAppException
    {
        public Demo2ValidationException()
        {

        }
        public Demo2ValidationException(string message)
            : base(message)
        {

        }
    }
}
