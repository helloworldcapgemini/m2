﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Test2
    {
        static void Main(string[] args)
        {
            int num=0;
            try
            {
                Console.WriteLine("Enter Even Number");
                num = int.Parse(Console.ReadLine());
                if(num%2!=0)
                {
                    throw new Demo2ValidationException("odd number is not allowed");
                }
            }

            catch(Demo2ValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch(MyAppException ex2)
            {
                Console.WriteLine(ex2.Message);
            }
            catch(Exception ex3)
            {
                Console.WriteLine(ex3.Message);
            }
            
            
            Console.WriteLine("You have entered:" + num);
            Console.ReadKey();
        }
    }
}
