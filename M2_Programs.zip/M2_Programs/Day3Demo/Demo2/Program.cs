﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, res = 0;
            try
            {
             
                
                Console.WriteLine("Enter value for n1");
                n1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter value for n2");
                n2 = int.Parse(Console.ReadLine());
               res = n1 / n2;
            }
            catch(DivideByZeroException dbzex)
            {
                Console.WriteLine(dbzex.Message);
                //Console.WriteLine("n2 Value should not be zero");
            }
            catch(FormatException fex)
            {
                //Console.WriteLine(fex.StackTrace);
                Console.WriteLine(fex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        
            Console.WriteLine("Result:" + res);
            Console.ReadKey();
        }
    }
}
