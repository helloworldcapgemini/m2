﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
   partial class MyClass
    {
        public string M1()
        {
            return "M1 is calling from myclass1.cs";
        }
    }
}
