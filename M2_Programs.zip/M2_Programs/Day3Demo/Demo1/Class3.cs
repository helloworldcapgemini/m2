﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
   partial class MyClass
    {
        public string M3()
        {
            return "M3 is calling from myclass3.cs";
        }
    }
}
