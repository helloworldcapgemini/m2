﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
  partial  class MyClass
    {
        public string M2()
        {
            return "M2 is calling from myclass2.cs";
        }
    }
}
