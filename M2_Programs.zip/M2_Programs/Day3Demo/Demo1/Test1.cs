﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Test1
    {
        public virtual void TestMethod()
        {

        }
    }

    class TestA:Test1
    {
        public sealed override void TestMethod()
        {
            base.TestMethod();
        }
    }
    class TestB:TestA
    {
        //public override void TestMethod()
        //{
        //    base.TestMethod();
        //}
    }
}
