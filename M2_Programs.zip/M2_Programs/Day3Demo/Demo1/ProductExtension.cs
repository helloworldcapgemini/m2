﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClsLib_ProductEntities;
namespace Demo1
{
   static class ProductExtension
    {
       public static int M1(this Product p,int i,int j)
       {
           return (i + j);
       }
    }
}
