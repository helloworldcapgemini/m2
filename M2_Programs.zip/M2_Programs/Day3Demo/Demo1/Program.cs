﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using ClsLib_ProductEntities;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Product p = new Product();
            //Console.WriteLine(p.M1(5,10));//extension method calling
            //p.ProdId = 101;
            //p.ProdName = "ABC";
            //p.value = 100;

            //Product p = new Product { ProdId = 101, value = 100, ProdName = "Lalit" };   //object intializer

            var p = new { PId = 101, PName = "pravin", sal = 92300 }; //anonymous type

            MyClass m = new MyClass();
            m.M1();
            m.M2;
            m.M3();
            

            Console.ReadKey();
        }
    }
}
