﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo3
{
    class hashtable_ex
    {
        static void Main(string[] args)
        {
            Hashtable hash = new Hashtable();
            hash.Add(1, "joydeep");
            hash.Add(2, "manu");
            hash.Add(3, "jini");
            hash.Add(4, "piku");
            //hash.Add(3, "chiku");  //get exception
            Console.WriteLine("The keys and values are:");
            foreach(int k in hash.Keys)
            {
                Console.WriteLine(k);
                Console.WriteLine(hash[k].ToString());
            }
            Console.ReadKey();
        }
    }
}
