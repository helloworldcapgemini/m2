﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    //Myutil obj = new Myutil();
        //    ////Itest1 t1 = (Itest1)obj;
           
        //    ////t1.m2();
        //    ////obj.m1();
        //    ////obj.m3();
        //    ////Itest2 t2 = (Itest2)obj;
        //    ////t2.m2();
        //    //foreach (var item in obj)
        //    //{
        //    //    Console.WriteLine(var);
        //    //}
        //    int[] nos = { 10, 203, 4, 5, 62, 56, 23 };
        //    //foreach-IEnumerable
        //    foreach (var item in nos)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    //basic iteration-IEnumerator(current,MoveNext())
        //    IEnumerator i1 = nos.GetEnumerator();
        //    while(i1.MoveNext())
        //    {
        //        Console.WriteLine(i1.Current);
        //    }
        //    Console.ReadKey();
        //}
    }
}
