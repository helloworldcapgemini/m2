﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    //interface Itest1
    //{
    //    void m1();
    //    void m2();
    //}
    //interface Itest2
    //{
    //    void m2();
    //    void m3();
    //}
    //class Myutil:Itest1,Itest2,ICollection
    //{
    //    public void m1()
    //    {
    //        Console.WriteLine("in m1.test1");
    //    }
    //   void  Itest1.m2()
    //    {
    //        Console.WriteLine("in m2.test1");
    //    }
    //    void Itest2.m2()
    //    {
    //        Console.WriteLine("in m2.test2");
    //    }

    //    public void m3()
    //    {
    //        Console.WriteLine("in m3.test2");
    //    }



    //    public IEnumerator GetEnumerator()
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
