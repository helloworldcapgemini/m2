﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    class arraylist
    {
        static void Main(string[] args)
        {
           
            ArrayList arr = new ArrayList();
            arr.Add("john");
            arr.Add("john2");
            arr.Add("john3");
            for(int i=0;i<arr.Count;i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.ReadKey();
        }
    }
}
