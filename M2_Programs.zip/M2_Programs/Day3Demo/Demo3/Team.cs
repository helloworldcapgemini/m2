﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3
{
    //class Player
    //{
    //    public int ID { get; set; }
    //    public string Name { get; set; }
    //}
    //class Team:ICollection,IList
    ////{
    ////    Player[] players = null;
    ////    public Team(int size)
    ////    {
    ////        players = new Player[size];
    ////    }

    ////    public void CopyTo(Array array, int index)
    ////    {
    ////        throw new NotImplementedException();
    ////    }

    ////    public int Count
    ////    {
    ////        get { throw new NotImplementedException(); }
    ////    }

    ////    public bool IsSynchronized
    ////    {
    ////        get { throw new NotImplementedException(); }
    ////    }

    ////    public object SyncRoot
    ////    {
    ////        get { throw new NotImplementedException(); }
    ////    }

    ////    public IEnumerator GetEnumerator()
    ////    {
    ////        return players.GetEnumerator();
    ////    }
    //}
}
