﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClsLib_ProductEntities;

namespace ClsLib_ProductEntities
{
    public class Product
    {
        public int ProdId { get; set; }
        public string ProdName { get; set; }
        public decimal value { get; set; }

    }
}
