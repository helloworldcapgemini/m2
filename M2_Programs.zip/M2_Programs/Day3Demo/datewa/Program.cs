﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datewa
{
    class Program
    {
        static void Main(string[] args)
        {
        //    public static Employee CreateEmployee( )
        //{
        //    Employee emp = new Employee();
        //    //Console.WriteLine("Enter the emp id");
        //    //emp.Id = int.Parse(Console.ReadLine());
        //    //// Console.WriteLine("Select Department(1.HR, 2.Operation, 3.Admin, 4.Finance,5. Other");
        //    ////emp.Department=(Department)int.Parse(Console.ReadLine());
        //    //Console.WriteLine("Enter department name:");
        //    //emp.Department=(Department)Enum.Parse(typeof(Department),Console.ReadLine());
        //    return emp;
        //}
            //Console.WriteLine(DateTime.Now);
            //Console.WriteLine(DateTime.Now.ToLongDateString());
            //Console.WriteLine(DateTime.Now.ToLongTimeString());
            //Console.WriteLine(DateTime.Now.ToShortDateString());
            //Console.WriteLine(DateTime.Now.ToShortTimeString());
            //Console.WriteLine(DateTime.Now.ToString("ddd-MMM-yyyy"));

            //DateTime dt1 = DateTime.Now;
            //DateTime dt2 = dt1.AddDays(-5);
            //DateTime dt3 = dt1.AddDays(5);
            //Console.WriteLine(dt1 + "\n" + dt2 + "\n" + dt3 + "\n");
            DateTime dt1;
            string str = "22-10-17";
            dt1 = DateTime.ParseExact(str, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);
            Console.WriteLine("Day: " + dt1.Day + "\tMonth: " + dt1.Month + "\tYear:" + dt1.Year);

            Console.ReadKey();
        }
    }
}
