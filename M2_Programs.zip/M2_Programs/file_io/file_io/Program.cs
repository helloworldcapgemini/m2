﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace file_io
{
    class Program
    {
        static void Main(string[] args)
        {
            student s1 = new student() { Rollno = 101, name = "nikhil", Marks = 100F };
            FileStream fileStream01 = new FileStream("d:\\test.txt", FileMode.Create, FileAccess.Write);
            BinaryWriter binaryWriter = new BinaryWriter(fileStream01);
            //binaryWriter.Write(54);
            //binaryWriter.Write("IGATEPATNI");
            //binaryWriter.Write(65.76);
            binaryWriter.Write(s1.Rollno);
            binaryWriter.Write(s1.name);
            binaryWriter.Write(s1.Marks);

            binaryWriter.Close();
            fileStream01.Close();

            FileStream fileStream02 = new FileStream(@"d:\test.txt", FileMode.Open, FileAccess.Read);
            BinaryReader binaryReader = new BinaryReader(fileStream02);
            Console.WriteLine(binaryReader.ReadInt32());
            Console.WriteLine(binaryReader.ReadString());
            //Console.WriteLine(binaryReader.ReadDouble());
            Console.WriteLine(binaryReader.ReadSingle());
            //Console.WriteLine(binaryReader.ReadInt32());
            
            binaryReader.Close();
            fileStream02.Close();

            Console.ReadKey();
        }
    }
}
