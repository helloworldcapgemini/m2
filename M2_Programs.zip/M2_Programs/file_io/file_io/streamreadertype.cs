﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace file_io
{
    class streamreadertype
    {
        static void Main(string[] args)
        {
            FileStream fileStream01 = new FileStream("d:\\test1.txt", FileMode.Create, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(fileStream01);
            streamWriter.WriteLine("this is a Test");
            streamWriter.WriteLine("this is a GHANTA");
            streamWriter.WriteLine("choti diwalichya shubhechya");
            streamWriter.Flush();
            streamWriter.Close();
            fileStream01.Close();

            FileStream fileStream02 = new FileStream("d:\\test1.txt", FileMode.Open, FileAccess.Read);
            StreamReader streamReader = new StreamReader(fileStream02);
            //Console.WriteLine(streamReader.ReadLine());
            //Console.WriteLine(streamReader.ReadLine());
            //Console.WriteLine(streamReader.ReadLine());
            Console.WriteLine(streamReader.ReadToEnd());
            
            streamReader.Close();
            fileStream02.Close();

            Console.ReadKey();

        }
    }
}
