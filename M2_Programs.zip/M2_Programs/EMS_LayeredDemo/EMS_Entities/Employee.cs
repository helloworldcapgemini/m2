﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Entities
{
    public enum Department { HR, Operation, Admin, Finance, Other }
        public class Employee
        {
            public int Id { get; set; }
            public String Name { get; set; }
            public DateTime DOJ { get; set; }
            public String MobileNo { get; set; }
            public string Gender { get; set; }
            public Department Department { get; set; }

        }
    
}
