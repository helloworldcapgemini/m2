﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using EMS_Entities;
namespace EMS_DAL
{
   public class EmployeeDAL
   {
       //data-Store
      public static ArrayList al_Emps = new ArrayList();

       //select-ALL-Employee
       public static ArrayList SelectAll()
       {
           return al_Emps;
       }
       //Insert Employee
       public static void Insert(Employee emp)
       {
           al_Emps.Add(emp);
       }
       //update Employee
       public static void Update(Employee emp)
       {
           for(int i=0;i<al_Emps.Count;i++)
           {
               var dEmp=(Employee)al_Emps[i];
               if(dEmp.Id==emp.Id)
               {
                   dEmp.Name = emp.Name;
                   dEmp.DOJ = emp.DOJ;
                   dEmp.Department = emp.Department;
                   dEmp.Gender = emp.Gender;
                   dEmp.MobileNo = emp.MobileNo;
               }
           }
       }
       //   Delete Employee
       public static void Delete(int empid)
       {
           for (int i = 0; i < al_Emps.Count; i++)
           {
               var dEmp=(Employee)al_Emps[i];
               if(dEmp.Id==empid)
               {
                   //al_Emps.Remove(al_Emps[i]);
                   al_Emps.RemoveAt(i);
                   break;
               }
           }
       }
   }
    
}
