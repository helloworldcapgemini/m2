﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_DAL;
using EMS_BAL;
using EMS_Exceptions;
namespace EMS_PL
{
    class Program
    {
        
         
        static void Main(string[] args)
        {
           //before calling any method from BAL,you will have to
            //validat4e obj through BA.IsValid();
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        
                        break;
                    case 2:
                        //ListAllGuests();
                        break;
                    case 3:
                        //SearchGuestByID();
                        break;
                    case 4:
                        //UpdateGuest();
                        break;
                    case 5:
                        //DeleteGuest();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);

        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********EMPLOYEE Menu***********");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Modify Employee Details");
            Console.WriteLine("3. List all the Employee");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
