﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS_Entities;
using System.Collections;
using EMS_DAL;
using EMS_Exceptions;
using EMS_Entities;
namespace EMS_BAL
{
    public class EmployeeBAL
    {
        public static bool Validate(Employee emp)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (emp.Id <= 0)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Invalid Employee ID");
            }
            if(emp.Name=="")
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Invalid Employee NAME");
            }
            if(emp.Gender.ToLower()!="male" || emp.Gender.ToLower()!="female"")
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Gender can be male or female");
            }
            if(emp.MobileNo.Length==10)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Mobile number should have 10 digit");
            }
            if(isValid==false)
            {
                throw new EmployeeException(sb.ToString());
            }
            //write code to validate properties of emp
            //ex-DOJ should be past date
            //gender should be male or female etc
            //throw exception in specific cases.
            return isValid;
        }

        public static ArrayList getAll()
        {

            return EmployeeDAL.SelectAll();
        }

        public static bool Add(Employee emp)
        {
            bool emp_added=false;
            if(Validate(emp))
            {
                
            }
            EmployeeDAL.Insert(emp);
        }
        public static void Modify(Employee emp)
        {
            EmployeeDAL.Update(emp);
        }
        public static void Remove(int empId)
        {
            EmployeeDAL.Delete(empId);
        }

    }
}
