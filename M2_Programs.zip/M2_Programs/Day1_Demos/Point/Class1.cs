﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Point
{
    public class Point

    {
        public int PointX { get; set; }
        public int PointY { get; set; }
    }
}
