﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp_Demo1
{
    class myclass2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("In myclass2");
            Console.ReadKey();
        }
    }
}
