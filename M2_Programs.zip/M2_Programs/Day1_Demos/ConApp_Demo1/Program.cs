﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp_Demo1
{
    class myclass
    {
        int a;
    }
    class Program
    {
        static void Main(string[] args)
        {
            int a=0;
            string s;
            object o=null;
            myclass my = new myclass();
            o = a;
            var v1 = a;
         
            Console.WriteLine(o.GetType().Name);

            if(a == null)
            Console.WriteLine("is null");
            else
            Console.WriteLine("not null");
           
            double b = 123.36;
            int c = (int)b+a;
            Console.WriteLine(c);
            string name = "Yahoo";
            Console.WriteLine("oh ho");
            Console.WriteLine(name);
            Console.WriteLine("Enter your empid");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your Name");
            name= Console.ReadLine();
            Console.WriteLine("Name is:" + name);
            Console.WriteLine("Id is:" + id);
             Console.ReadKey();
        }
    }
}
