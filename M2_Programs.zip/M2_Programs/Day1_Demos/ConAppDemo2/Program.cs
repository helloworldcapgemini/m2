﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClsLib_EmpDeptClass1;
namespace ConAppDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Employee emp2 = new Employee();
            Employee emp3 = new Employee();
            Console.WriteLine("Total number of instance created till now: " + Employee.EmpCount);
            Console.WriteLine("Enter EmpId: ");
            int empId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Empname: ");
            string empname = Console.ReadLine();
            Console.WriteLine("Enter salary: ");
            double salary = double.Parse(Console.ReadLine());
            Employee emp4 = new Employee(empId,empname,salary);
            Console.WriteLine("Total number of instance created till now: " + Employee.EmpCount);

            Console.WriteLine("Enter new name for Emp4: ");
            emp4.EmpName = Console.ReadLine();//use property to set value;
            Console.WriteLine("emp4 name is : " + emp4.EmpName);
            Console.WriteLine(emp4.GetEmpDetails());
            Console.ReadKey();
        }
    }
}
