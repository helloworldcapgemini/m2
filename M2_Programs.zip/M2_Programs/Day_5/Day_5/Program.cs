﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demo
{

    class Program //suscriber
    {

        static void Main(string[] args)
        {
            //setp 2:Creating Instance of delegate
            //NotificationDelegate del=new NotificationDelegate(Notification.SendSMS);
            //del += new NotificationDelegate(Notification.SendEmail);
            //del += new NotificationDelegate(Notification.SendVoiceCall);
            //del -= new NotificationDelegate(Notification.SendEmail);
            BankAccount bankAcc = new BankAccount(5000);
            //bankAcc.BalanceChanged += Notification.SendEmail;//step-2 suscribe a event
            bankAcc.Deposit(10000);
            bankAcc.withdraw(15000);
            Console.ReadKey();
        }
    }
}
