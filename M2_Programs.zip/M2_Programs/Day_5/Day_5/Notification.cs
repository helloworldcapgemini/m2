﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demo
{
    class Notification
    {
        public static void  SendEmail(string message)
        {
            Console.WriteLine("Mail:"+message);
        }
        public static void SendSMS(string message)
        {
            Console.WriteLine("sms:"+message);
        }
        public static void SendVoiceCall(string message)
        {
            Console.WriteLine("VoiceCall:" + message);
        }
    }
}
