﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demo
{
    //step-1 defining delegates
    delegate void NotificationDelegate(string message);
    class BankAccount //publishers
    {

        static int count = 0;
        //NotificationDelegate del;
        public int AccNo { get; set; }
        public decimal Balance { get; set; }
        public event NotificationDelegate BalanceChanged;//step-1 declare a event
        public BankAccount(decimal balance)
        {
            //this.del = del;
            count++;
            AccNo = 1000 + count;
            Balance = balance;
        }
        public void withdraw(decimal amount)
        {
            decimal oldbal=Balance;
            Balance = Balance - amount;
            //step 3 Invoking Delegate
            //step 3 raise event
            if (BalanceChanged != null)
            BalanceChanged(AccNo + " Balance getting changed from " + oldbal + " to " + Balance);
            //del(AccNo+" Balance getting changed from " + oldbal + " to " + Balance);

        }
        public void Deposit(decimal amount)
        {
            //Balance = Balance + amount;
            decimal oldbal = Balance;
            Balance += amount;
            if(BalanceChanged!=null)
            BalanceChanged(AccNo + " Balance getting changed from " + oldbal + " to " + Balance);
            //del(AccNo+" Balance getting changed from " + oldbal + " to " + Balance);
        }
    }
}
