﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demos2
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc c=new Calc();
            //Console.CalcDelegate<int, int> del1 = new CalcDelegate<int, int>(c.Add);
            CalcDelegate<int,int> del1= delegate(int first,int second)
            {
                //Console.WriteLine("The sum is:"+(first+second));
                return first + second;
            };
           Console.WriteLine("Sum is by delegate: "+ del1(10, 20));

           CalcDelegate<int, int> del2 = (first, second) => { return (first + second); };
           Console.WriteLine("Sum by Lambda Expression : " + del2(10, 20));
            Console.WriteLine(del1(10, 20));
            //CalcDelegate<float, float> del2 = new CalcDelegate<float, float>(c.AddFloat);
            //Console.WriteLine(del2(10.5F, 20.5F));
            CalcDelegate<string, int> del3 = new CalcDelegate<string, int>(c.ConcateNumber);
            Console.WriteLine(del3(10,41));
            Console.ReadKey();



        }
    }
}
