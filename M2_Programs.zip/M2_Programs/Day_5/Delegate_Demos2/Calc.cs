﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate_Demos2
{
    //STEP 1
    delegate R CalcDelegate<R,P>(P p1,P p2);
    class Calc
    {
        public  int Add(int n1,int n2)
        {
            return n1 + n2;
        }
        public  float AddFloat(float n1, float n2)
        {
            return n1 + n2;
        }
        public string ConcateNumber(int n1,int n2)
        {
            return n1 + "" + n2;
        }
    }
}
