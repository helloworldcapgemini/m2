﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClsLib_EmpDeptClass1;
namespace ConApp_EmpMgntSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp1;
            //emp1 = new SalesPerson(101, "Jayesh", 45000, 40000);
            ////string details = emp1.GetEmpDetails();
            //Console.WriteLine(emp1);
            //emp1.CalcSalary();

            SimpleCalculator s1 = new SimpleCalculator();
            Console.WriteLine(s1.Add(10,20));
            Console.WriteLine(s1.sub(20, 100));

            Console.ReadKey();
            
        }
    }
}
