﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsLib_EmpDeptClass1
{
   public class SalesPerson : Employee
    {
        int kmTraveled;
        double travelAll;
       
        public SalesPerson(int empId,string empName,double Salary,int kmTraveled )
            :base(empId,empName,Salary)
        {
            this.kmTraveled = kmTraveled;
        }

        public override void CalcSalary()
        {
            travelAll=5*kmTraveled;
            gs = Salary + travelAll;
        }
       
    }
}
