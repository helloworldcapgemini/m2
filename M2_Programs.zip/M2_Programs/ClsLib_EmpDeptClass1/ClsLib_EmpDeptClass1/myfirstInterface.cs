﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsLib_EmpDeptClass1
{
    interface ICalculation
    {
        int Add(int n1, int n2);
        int sub(int n1, int n2);
    }
    //public abstract class ICalculation
    //{
    //    public abstract int Add(int n1, int n2);
    //    public abstract int sub(int n1, int n2);

    //}
}
