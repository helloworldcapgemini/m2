﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsLib_EmpDeptClass1
{
    public abstract class Employee
    {
      protected int empId;
      protected string empName;
      protected double Salary;
      protected double gs;
        //pf,hra,tds;
        public Employee(int empId,string empName,double Salary)
        {
            this.empId = empId;
            this.empName = empName;
            this.Salary = Salary;
        }

        //public String GetEmpDetails()
        //{
        //    return "ID: " + empId + "\n" + "Name: " + empName + "\n" + " Salary " + Salary;
        //}

        //public virtual void CalcSalary()
        //{
        //    gs = Salary;
        //}
        public abstract void CalcSalary();
        public override string ToString()
        {
            return "ID: " + empId + "\n" + "Name: " + empName + "\n" + " Salary " + Salary;
        }
    }

    //public class Employee
    //{
    //    public static int count { get; private set; }
    //    public int EmpId { get; set; }
    //    public string EmpName { get; set; }
    //    public double Salary { get; set; }
    //    public Employee()
    //    {
    //        count++;
    //        EmpId = count;
    //    }
    //    public Employee(string empName, double salary)
    //    {
    //        count++;
    //        this.EmpId = count;
    //        this.EmpName = empName;
    //        this.Salary = salary;
    //    }
        
    //    public String GetEmpDetails()
    //    {
    //        return "ID: " + EmpId + "\n" + "Name: " + EmpName + "\n" + " Salary " + Salary;
    //    }
    //}
}
