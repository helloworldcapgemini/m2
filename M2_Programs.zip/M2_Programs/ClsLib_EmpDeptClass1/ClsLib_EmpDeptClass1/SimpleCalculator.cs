﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClsLib_EmpDeptClass1
{
    public class SimpleCalculator:ICalculation
    {

        public  int Add(int n1, int n2)
        {
            return n1 + n2;  
        }

        public int sub(int n1, int n2)
        {
            return n1 - n2;
        }
    }
}
